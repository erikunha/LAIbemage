# LAIbemage Master — Technical Design Package

**Status:** proposta arquitetural / RFC, não software implementado.  **Data-base:** 2026-11-10. **Idioma:** PT-BR com terminologia técnica em inglês.

A plataforma proposta transforma imagens e vídeos em datasets auditáveis, modelos de visão avaliados, decisões explicáveis e workflows operacionais seguros. Preserva `ai-image-labeling` como CLI de compatibilidade durante a migração. Não modifica o repositório existente.

## Leia nesta ordem
1. `docs/00-vision-product.md` — tese, personas, resultados e limites.
2. `docs/01-stack-decisions.md` — stack completa, alternativas e implantação por estágio.
3. `docs/02-architecture.md` — C4, fronteiras, componentes, runtime, jobs e fluxos.
4. `docs/03-data-model.md` — modelo de domínio, imutabilidade, armazenamento, versionamento.
5. `docs/04-data-ingestion-annotation.md` — ingestão, curadoria, anotação, visual search.
6. `docs/05-ml-training-evaluation.md` — pipeline CV/ML, métricas, treino, experimentos, gate.
7. `docs/06-api-contracts.md` — OpenAPI e contratos assíncronos.
8. `docs/07-cli-sdk-mcp.md` — superfícies para devs e agentes.
9. `docs/08-agent-design.md` — LangGraph, segurança, contexto, ferramentas, evals.
10. `docs/09-frontend-ux.md` — Studio, IA, componentes, acessibilidade, performance.
11. `docs/10-security-governance.md` — threat model, controles, licenças, LGPD.
12. `docs/11-observability-sre.md` — traces, métricas, incidentes, SLOs.
13. `docs/12-testing-quality.md` — pirâmide e matrizes de teste, gates.
14. `docs/13-infra-deployment.md` — perfis local/self-hosted/cloud, backups e release.
15. `docs/14-roadmap-backlog.md` — épicos, sprints, critérios de aceite e dependências.
16. `docs/15-research-references.md` — referências oficiais e material técnico.
17. `docs/16-definition-of-done.md` — checklist completo por marco.
18. `docs/17-implementation-playbook.md` — contribuição, fluxo de PR e prompts de agente.
19. `docs/18-risk-register.md` — riscos, hipóteses, indicadores e mitigação.
20. `adrs/` — decisões com contexto, trade-offs, consequências e alternativas.
21. `contracts/` — schema SQL, JSON Schema e exemplo OpenAPI.
22. `examples/` — configuração declarativa de experimento, qualidade e política de release.

## Status dos arquivos
- Docs = decisões/propostas técnicas; **não** implicam implementação ou testes do sistema.
- Contratos = artefatos de referência para evolução, não API pública já estável.
- Metas = alvos iniciais, dependentes de baseline e risco; não medições observadas.
- Trechos de código = exemplos de contrato; implementar, testar e versionar antes de produção.

## Estratégia
- **North star:** custo por decisão visual correta, sob restrições de cobertura, latência e riscos de erro.
- **Primeiro vertical slice:** inspeção visual industrial com dataset público licenciado, linear probe local + VLM, UI de revisão, MLflow, avaliação e análise de custos.
- **Expansão:** detecção/segmentação, active learning, treinamento especializado, agente com MCP, vídeo/edge, multi-tenant.
- **Fora da primeira entrega:** captura em tempo real, SAM pesado sem hardware, multi-agent swarm, K8s, federated learning, simuladores físicos, pagamentos e automações operacionais irreversíveis.

## Fontes de partida
Código original: https://github.com/erikunha/LAIbemage ; exemplo de avaliação e tracing: https://github.com/erikunha/ledgerlens . Detalhes, versões e licenças devem ser revalidados quando o código for criado.
