# ADR-001 — Monorepo TS+Python, bounded contexts
**Status:** Proposed, 2026-11-10

## Contexto
O produto expõe múltiplas interfaces e workflows de CV, modelo e anotação. Separar cada competência em microservices desde o início aumentaria rede, contratos, deployment e custo de observabilidade; concentrar ML em Node comprometeria bibliotecas e aprendizado.

## Decisão
Usar monorepo: apps (`studio`, `api`), TS packages (`domain`, `application`, `contracts`, `sdk`, `cli`, `mcp`) e Python ML/agent packages (uv workspace ou subprojetos com locks isolados quando conflito). Backend TS modular monolith e Python executado em processos/containers isolados por job. Expor só contratos JSON/OpenAPI/versioned. Plugins de modelos por capability registry. `features` podem ser extraídas para serviços independentes quando SLO/escala/ownership o justificarem.

## Alternativas
1. Full Python FastAPI + React: simplifica ML integration, mas dificulta reaproveitar SDK/CLI TypeScript. Pode tornar-se preferível se o front não compartilhar casos de uso.
2. Microservices por domínio: favorece equipes grandes e escala independente, mas prematuro.
3. Full TS com onnx/TFJS: perde flexibilidade de treinamento e experimentação Python.

## Consequências
Duas linguagens, contrato/generation/CI extra; fronteiras claras e curva de aprendizado rica. Precisa impedir duas implementações do mesmo domínio e manter testes de paridade.

## Revisar se
Mais de 3 perfis de deploy exigem divisão real, latência IPC vira gargalo, ou o custo de contratos supera a colaboração.
