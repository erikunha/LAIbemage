# ADR-002 — PostgreSQL-first, single operational source of truth
**Status:** Proposed, 2026-11-10

## Contexto
Dados incluem relações de snapshots, annotations, jobs, auth, experiments e audit. Vários stores iniciais criariam consistência distribuída prematura.

## Decisão
PostgreSQL para estado operacional e outbox, pgvector para a primeira busca embedding, FTS para OCR/descriptions e fila PostgreSQL-backed. CAS filesystem ou S3 para bytes. DuckDB/Parquet para leitura analítica, MLflow para tracking. Não usar Milvus, Redis, Elastic e graph DB em P0. DB roda local via Compose: local-first não significa serverless.

## Alternativas
SQLite-first: muito fácil de instalar, mas implicaria caminho de migração/two-dialect para multiusuário e alta escrita. Reavaliar modo standalone portátil após benchmark.
LanceDB-first: forte para vetores/curadoria, mas não resolve transações de jobs, auth e annotation; adicionar como índice secundário quando pgvector saturar.

## Trade-offs
Docker/Postgres aumenta footprint local; pgvector pode não escalar para multimodal bilionário; testes reais de performance são necessários. PostgreSQL não vira storage de mídia.

## Revisar se
Adesão local é impedida por Postgres, dataset dimension/recall/latency exigem outro índice ou pipelines analíticos sobrecarregam o banco.
