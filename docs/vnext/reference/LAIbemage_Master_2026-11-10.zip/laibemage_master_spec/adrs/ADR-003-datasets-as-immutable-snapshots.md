# ADR-003 — Snapshot imutável com annotations e ontology versionadas
**Status:** Proposed, 2026-11-10

## Contexto
Model metrics se tornam não reproduzíveis se o corpus, etiquetas ou split mudam após treino. Rótulos sugeridos por modelos e ground truth humano precisam ser distinguíveis.

## Decisão
Asset bytes content-addressed, annotations append-only revisions, ontology immutable version, DatasetSnapshot com manifest digest contendo samples, revisions e split. Train/eval requerem snapshot id. Guard de leakage e licenciamento antes de snapshot. Mudanças humanas geram nova versão, nunca alteram avaliação anterior. Separar `Prediction` de `Annotation`.

## Alternativas
Atualizar labels in-place: mais simples mas quebra histórico; não aceitar. Somente DVC: versiona artefatos de pesquisa, mas não dá autorização granular/UX de anotação; DVC permanece complemento.

## Consequências
Maior armazenamento de metadata, workflow de snapshots explícito e garbage collection cuidadoso. Reprodutibilidade e auditoria superiores.
