# ADR-004 — Agentes recomendam; ferramentas e approvals autorizam
**Status:** Proposed, 2026-11-10

## Contexto
Agentes precisam pesquisar datasets, comparar modelos e propor experimentos. Modelos podem sofrer prompt injection, alucinação de recursos e loops caros.

## Decisão
Agente (LangGraph) usa apenas application-tool registry allowlisted. Scopes avaliados por operação, limites tokens/wall/cost, checkpointed state, approval tokens específicos ao hash da proposta. Read-only por default. Deploy/treino caro/export e mutações de taxonomia exigem confirmação. EvidenceRefs e deterministic verifier antes de conclusão. Um agente primeiro, não swarm.

## Alternativas
Autonomia total para produtividade: risco excessivo e difícil de depurar. Workflows 100% determinísticos: devem continuar como baseline e substituem agente quando desempenho é equivalente.

## Consequências
Mais fricção de aprovação em mudanças sensíveis; potencialmente melhor confiabilidade. Precisamos de agent eval e threat model próprio.
