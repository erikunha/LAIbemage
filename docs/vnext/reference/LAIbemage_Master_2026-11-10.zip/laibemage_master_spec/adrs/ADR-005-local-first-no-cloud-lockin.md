# ADR-005 — Local-first e provider adapters, sem lock-in de nuvem
**Status:** Proposed, 2026-11-10

## Contexto
Dados visuais podem ser privados/custosos para enviar. Mac M2 oferece caminho para baseline local; cloud continua útil para modelos específicos.

## Decisão
Toda feature central do vertical slice deve funcionar sem conta cloud: modelos CPU/MPS, CAS local, PG Compose, eval/training local. Cloud providers são opt-in, com budgets e policy. Interfaces StoragePort, ModelAdapter, EmbeddingAdapter e InferenceAdapter evitam dependência de SDKs nos casos de uso. Não prometer paridade de qualidade/performance entre local e cloud sem benchmark.

## Trade-offs
Bootstrap local requer downloads licenciados de weights e recursos. Modelos grandes nem sempre cabem localmente; fallback quando cliente autoriza cloud ou usar modelo pequeno/abstain.
