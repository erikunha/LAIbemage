# ADR-006 — Evaluation-first, modelos não são feature sem benchmark
**Status:** Proposed, 2026-11-10

## Contexto
Benchmarks sintéticos de cor podem testar pipeline mas não precisão visual; confiança gerada por VLM não significa probabilidade de acerto.

## Decisão
Snapshot gold com split por grupos, baseline simples, métricas por tarefa/classe, IC por grupo, calibrated thresholds e adverse slices. ExperimentRun com hardware/seed/commit/artifact. Toda promoção considera constraints de qualidade/custo/risco; relatório registra erro e não só averages. Mínimo: linear probe vs VLM em mesmo snapshot de dataset público real. Investigar ROI do active learning contra amostragem aleatória.

## Trade-offs
Mais trabalho de curadoria antes do produto visual; reduz autoengano. Requer orçamento, disciplina e reporte de resultados negativos.
