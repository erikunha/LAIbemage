# ADR-007 — MCP 2026-07-28 e compatibilidade isolada
**Status:** Proposed, 2026-11-10

## Contexto
O MCP estável de 2026-07-28 é stateless e o SDK TypeScript v2 implementa essa revisão. Clientes corporativos podem usar revisões antigas que negociam sessão/initialize de forma diferente. Incompatibilidade silenciosa pode quebrar clientes e segurança.

## Decisão
Implementar interface MCP com SDK TypeScript v2 e spec 2026-07-28 em stdio. Cada tool usa casos de uso autenticados, output schema e resource handles; nenhum estado de autorização está baseado em conexão. Para clientes antigos, adapter isolado com testes de compatibilidade, não fallback implícito que misture semânticas. Streamable HTTP apenas quando houver necessidade de integração remota com auth, origin/host e observabilidade.

## Referências
https://modelcontextprotocol.io/specification/2026-07-28
https://ts.sdk.modelcontextprotocol.io/v2/
