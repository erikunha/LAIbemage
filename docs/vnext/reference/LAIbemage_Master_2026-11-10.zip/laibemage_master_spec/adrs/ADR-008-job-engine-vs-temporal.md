# ADR-008 — Fila durável em Postgres, Temporal somente quando necessário
**Status:** Proposed, 2026-11-10

## Contexto
Ingestão, embeddings, training e avaliação são jobs assíncronos, potencialmente longos. Workflow resiliente é necessário, mas Temporal/Redis/Kafka em P0 criariam operação prematura.

## Decisão
PostgreSQL-backed queue (avaliar pg-boss ou equivalente), app-owned state machine, idempotency keys, leases, retry policy, cancellation, outbox. TS worker executa Python tasks isoladas; checkpoints e artifacts persistem separadamente. Ao atingir multi-day workflows com compensation/HITL complexa, fazer benchmark/ADR para Temporal.

## Consequências
Precisamos implementar política de estados, lease renewal, worker retry e outbox; sem transações distribuídas completas. Documentar limites de exatamente-uma-vez: preferir at-least-once + idempotência.
