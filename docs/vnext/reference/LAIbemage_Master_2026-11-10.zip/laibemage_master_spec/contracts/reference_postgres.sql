-- LAIbemage Master: REFERÊNCIA de modelo relacional (não migration de produção).
-- PostgreSQL >= 15 sugerido. Aplicar com ferramenta de migration após testes.
-- Extensões e permissões devem ser provisionadas por operador autenticado.

CREATE TABLE IF NOT EXISTS workspaces (
  id UUID PRIMARY KEY,
  name TEXT NOT NULL CHECK (char_length(name) BETWEEN 1 AND 255),
  mode TEXT NOT NULL DEFAULT 'local' CHECK (mode IN ('local','team','enterprise')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS datasets (
  id UUID PRIMARY KEY,
  workspace_id UUID NOT NULL REFERENCES workspaces(id),
  name TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','archived')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (workspace_id, name)
);
CREATE INDEX IF NOT EXISTS idx_datasets_workspace ON datasets(workspace_id, created_at DESC);

CREATE TABLE IF NOT EXISTS assets (
  id UUID PRIMARY KEY,
  workspace_id UUID NOT NULL REFERENCES workspaces(id),
  sha256 CHAR(64) NOT NULL CHECK (sha256 ~ '^[a-f0-9]{64}$'),
  storage_ref TEXT NOT NULL,
  mime_type TEXT NOT NULL,
  bytes_size BIGINT NOT NULL CHECK (bytes_size > 0),
  width INTEGER CHECK (width > 0),
  height INTEGER CHECK (height > 0),
  captured_at TIMESTAMPTZ,
  provenance_source TEXT NOT NULL,
  license_id TEXT,
  pii_sensitive BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (workspace_id, sha256),
  UNIQUE (id, workspace_id)
);

CREATE TABLE IF NOT EXISTS samples (
  id UUID PRIMARY KEY,
  workspace_id UUID NOT NULL,
  dataset_id UUID NOT NULL REFERENCES datasets(id),
  asset_id UUID NOT NULL,
  capture_group_id TEXT,
  sample_kind TEXT NOT NULL DEFAULT 'image' CHECK (sample_kind IN ('image','crop','frame','clip')),
  geometry JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  FOREIGN KEY (asset_id,workspace_id) REFERENCES assets(id,workspace_id),
  UNIQUE (id,dataset_id)
);
CREATE INDEX IF NOT EXISTS idx_samples_dataset ON samples(dataset_id, id);
CREATE INDEX IF NOT EXISTS idx_samples_capture_group ON samples(dataset_id,capture_group_id);

CREATE TABLE IF NOT EXISTS ontology_versions (
  id UUID PRIMARY KEY,
  dataset_id UUID NOT NULL REFERENCES datasets(id),
  version_number INTEGER NOT NULL CHECK (version_number > 0),
  ontology_json JSONB NOT NULL,
  sha256 CHAR(64) NOT NULL CHECK (sha256 ~ '^[a-f0-9]{64}$'),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (dataset_id,version_number)
);

CREATE TABLE IF NOT EXISTS annotations (
  id UUID PRIMARY KEY,
  dataset_id UUID NOT NULL,
  sample_id UUID NOT NULL,
  ontology_version_id UUID NOT NULL REFERENCES ontology_versions(id),
  supersedes_annotation_id UUID REFERENCES annotations(id),
  source TEXT NOT NULL CHECK (source IN ('human','model','import')),
  status TEXT NOT NULL CHECK (status IN ('suggested','draft','approved','disputed')),
  task_type TEXT NOT NULL,
  payload JSONB NOT NULL,
  actor_ref TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  FOREIGN KEY (sample_id,dataset_id) REFERENCES samples(id,dataset_id)
);
CREATE INDEX IF NOT EXISTS idx_annotations_sample ON annotations(sample_id,created_at DESC);

CREATE TABLE IF NOT EXISTS dataset_snapshots (
  id UUID PRIMARY KEY,
  dataset_id UUID NOT NULL REFERENCES datasets(id),
  ontology_version_id UUID NOT NULL REFERENCES ontology_versions(id),
  manifest_sha256 CHAR(64) NOT NULL CHECK (manifest_sha256 ~ '^[a-f0-9]{64}$'),
  split_policy TEXT NOT NULL,
  source_revision TEXT,
  frozen_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (dataset_id,manifest_sha256)
);

CREATE TABLE IF NOT EXISTS snapshot_samples (
  dataset_snapshot_id UUID NOT NULL REFERENCES dataset_snapshots(id),
  sample_id UUID NOT NULL REFERENCES samples(id),
  annotation_id UUID REFERENCES annotations(id),
  split TEXT NOT NULL CHECK (split IN ('train','val','test','unassigned')),
  PRIMARY KEY (dataset_snapshot_id,sample_id)
);
CREATE INDEX IF NOT EXISTS idx_snapshot_samples_split ON snapshot_samples(dataset_snapshot_id,split);

CREATE TABLE IF NOT EXISTS artifacts (
  id UUID PRIMARY KEY,
  workspace_id UUID NOT NULL REFERENCES workspaces(id),
  kind TEXT NOT NULL,
  sha256 CHAR(64) NOT NULL CHECK (sha256 ~ '^[a-f0-9]{64}$'),
  storage_ref TEXT NOT NULL,
  bytes_size BIGINT NOT NULL CHECK (bytes_size >= 0),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (workspace_id,sha256)
);

CREATE TABLE IF NOT EXISTS model_versions (
  id UUID PRIMARY KEY,
  workspace_id UUID NOT NULL REFERENCES workspaces(id),
  name TEXT NOT NULL,
  model_revision TEXT NOT NULL,
  task_type TEXT NOT NULL,
  artifact_id UUID REFERENCES artifacts(id),
  preprocess_sha256 CHAR(64) NOT NULL CHECK (preprocess_sha256 ~ '^[a-f0-9]{64}$'),
  ontology_version_id UUID REFERENCES ontology_versions(id),
  license_id TEXT,
  status TEXT NOT NULL DEFAULT 'candidate' CHECK (status IN ('candidate','approved','deployed','retired')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(workspace_id,name,model_revision)
);

CREATE TABLE IF NOT EXISTS experiment_runs (
  id UUID PRIMARY KEY,
  workspace_id UUID NOT NULL REFERENCES workspaces(id),
  dataset_snapshot_id UUID NOT NULL REFERENCES dataset_snapshots(id),
  model_version_id UUID REFERENCES model_versions(id),
  spec_artifact_id UUID NOT NULL REFERENCES artifacts(id),
  code_revision TEXT NOT NULL,
  hardware_json JSONB NOT NULL,
  mlflow_run_ref TEXT,
  status TEXT NOT NULL CHECK(status IN ('queued','running','succeeded','failed','canceled')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS evaluation_runs (
  id UUID PRIMARY KEY,
  workspace_id UUID NOT NULL REFERENCES workspaces(id),
  dataset_snapshot_id UUID NOT NULL REFERENCES dataset_snapshots(id),
  model_version_id UUID NOT NULL REFERENCES model_versions(id),
  report_artifact_id UUID NOT NULL REFERENCES artifacts(id),
  protocol_sha256 CHAR(64) NOT NULL CHECK (protocol_sha256 ~ '^[a-f0-9]{64}$'),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS predictions (
  id UUID PRIMARY KEY,
  evaluation_run_id UUID NOT NULL REFERENCES evaluation_runs(id),
  sample_id UUID NOT NULL REFERENCES samples(id),
  payload JSONB NOT NULL,
  raw_score DOUBLE PRECISION,
  calibrated_score DOUBLE PRECISION CHECK (calibrated_score BETWEEN 0 AND 1),
  latency_ms DOUBLE PRECISION CHECK (latency_ms >= 0),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(evaluation_run_id,sample_id)
);
CREATE INDEX IF NOT EXISTS idx_predictions_run ON predictions(evaluation_run_id,sample_id);

CREATE TABLE IF NOT EXISTS jobs (
  id UUID PRIMARY KEY,
  workspace_id UUID NOT NULL REFERENCES workspaces(id),
  kind TEXT NOT NULL,
  status TEXT NOT NULL CHECK(status IN ('queued','claimed','running','succeeded','failed','canceled','timed_out')),
  payload_artifact_id UUID NOT NULL REFERENCES artifacts(id),
  idem_key TEXT,
  idem_fingerprint CHAR(64),
  progress DOUBLE PRECISION NOT NULL DEFAULT 0 CHECK(progress BETWEEN 0 AND 1),
  error_code TEXT,
  cancel_requested BOOLEAN NOT NULL DEFAULT FALSE,
  attempts INTEGER NOT NULL DEFAULT 0 CHECK(attempts >= 0),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(workspace_id,kind,idem_key)
);
CREATE INDEX IF NOT EXISTS idx_jobs_workspace_status ON jobs(workspace_id,status,created_at);

CREATE TABLE IF NOT EXISTS outbox_events (
  id UUID PRIMARY KEY,
  workspace_id UUID NOT NULL REFERENCES workspaces(id),
  event_type TEXT NOT NULL,
  payload JSONB NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  dispatched_at TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_outbox_pending ON outbox_events(created_at) WHERE dispatched_at IS NULL;

CREATE TABLE IF NOT EXISTS audit_events (
  id UUID PRIMARY KEY,
  workspace_id UUID NOT NULL REFERENCES workspaces(id),
  actor_ref TEXT NOT NULL,
  action TEXT NOT NULL,
  resource_ref TEXT NOT NULL,
  outcome TEXT NOT NULL CHECK(outcome IN ('allow','deny','error')),
  trace_id TEXT,
  details_redacted JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_audit_workspace_time ON audit_events(workspace_id,created_at DESC);

-- Pós-migração: triggers/policies/guards devem validar:
-- 1) toda FK tem workspace/dataset compatível (algumas FKs cruzadas acima não verificam mesma tenant);
-- 2) snapshot_samples referenciam samples do mesmo dataset e annotations aprovadas do mesmo sample;
-- 3) ontology_version pertence ao dataset de annotations/snapshot;
-- 4) snapshot e annotations approved são imutáveis (preferir append-only revisions);
-- 5) políticas RBAC/RLS, retention, outbox atomicidade e job state machine;
-- 6) índices pgvector serão definidos somente após dimensions/modelo de embedding estabelecidos.
-- NÃO utilizar este SQL diretamente como esquema de produção sem completar esses invariantes.
