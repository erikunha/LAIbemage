# 00 — Visão de produto, escopo e critérios de sucesso

## 1. Problema
Equipes de CV/ML precisam descobrir quais dados possuem, corrigir rótulos, selecionar modelos adequados, validar regressões, monitorar resultados e operar a custos controlados. Soluções isoladas de anotação, experimentos, observabilidade e deployment criam interfaces descontinuadas e dificultam rastrear a origem de cada resultado.

**Proposta:** workbench local-first para engenharia de inteligência visual, com datasets versionados, anotação auditável, treinamento/avaliação reproduzíveis, agentes supervisionados e execução com custos observáveis.

## 2. Público e trabalhos a executar
| Persona | Job-to-be-done | Sinal de sucesso |
|---|---|---|
| ML/CV Engineer | Encontrar falhas e comparar modelos | Reduzir tempo até experimento válido |
| Data/Annotation Lead | Descobrir rótulos inconsistentes e direcionar revisão | Melhorar qualidade por hora de anotador |
| Platform Engineer | Operar pipelines e modelos confiáveis | Reproduzir e reverter deploys |
| Applied AI Engineer | Integrar VLMs, ferramentas e custos | Diminuir custo/resultado dentro de limites de qualidade |
| Product/Operations | Converter previsões em revisão/ação | Impacto mensurável sem decisões automáticas arriscadas |

## 3. Capabilities (visão de longo prazo)
- Data acquisition: uploads, pastas, S3 compatível, câmera e vídeo posterior.
- Visual catalog: imagem, vídeo, frame, region of interest, sequência e sensores futuros.
- Quality: hashes, perceptual duplicates, blur, broken images, leakage, outliers, imbalance, suspicious labels.
- Annotation: classification/multilabel, boxes, rotated boxes, polygons, masks, keypoints, OCR regions; versões e review.
- Search: visual-text embeddings, imagem-imagem, metadados, FTS, nearest neighbor, agrupamento e hard-example discovery.
- Models: linear probe, scikit-learn, PyTorch, ViT, CLIP/SigLIP/DINO, detectors, segmenters, VLMs e runtimes locais.
- ML loop: experiment definition, freeze dataset, training, eval, cost, registry, feedback, active learning.
- Agent: investigações read-only; planos de experimento; execução de jobs com limites; relatório com evidências.
- Interfaces: Studio, CLI, TS/Python SDK, REST/OpenAPI e MCP.
- Production: deploy, monitor, version pin, drift, canary, rollback, audit.

## 4. Prioridades de mercado
Hipótese comercial inicial: equipes de CV/ML com custo significativo de curadoria/inferência e necessidade de decisão auditável. Usar inspeção industrial como *benchmark vertical*, sem hardcode de domínio. Cliente e orçamento precisam ser validados: entrevistas com responsáveis por ML/platform, custos atuais, ferramentas usadas, intenção de pagamento e workflow real. Não assumir PMF.

## 5. North star e árvore de métricas
North star = **total cost per accepted visual decision**, somente comparável entre runs com o mesmo padrão de qualidade/risco.

```
cost_per_accepted_decision =
  (model_inference + data_capture + human_review + compute + storage + error_cost_estimate)
  / accepted_correct_decisions
```

Métricas-guarda: recall de classe crítica; precision; false positive rate; calibração; cobertura; p95; revisão/1000; drift; segurança; latência de job; disponibilidade. Nunca otimizar custo sacrificando silenciosamente recall crítico.

## 6. Não objetivos imediatos
- Treinar foundation models do zero, replicar CVAT inteiro, fazer um ERP, atuar como sistema médico regulado.
- Assumir que toda confidence de LLM é calibrada ou que modelo sintético garante ganho em dados reais.
- Executar código arbitrário enviado por agentes ou usuários.
- SaaS multi-tenant em P0; a evolução para múltiplos usuários existe no design, não na primeira implementação.

## 7. Requisitos não funcionais
Proveniência rastreável; separação prediction/ground truth; operações idempotentes; checkpoints e cancelamento; princípio de menor privilégio; observabilidade por run; acessibilidade; integração sem cloud obrigatória; licenças verificadas; testes de regressão e documentação dos limites.

## 8. Fluxo principal de demonstração
`Import → Audit → Create snapshot → Embed → Evaluate baseline → Compare candidate → Review hard cases → Train → Re-evaluate → Recommend (do not auto-promote) → Reproduce report`.

Critério de aceite do demo: toda tabela e métrica deriva de runs reais, exemplos revisáveis e hashes de dados/modelos; ao reexecutar em ambiente documentado, os resultados permanecem dentro das tolerâncias especificadas.
