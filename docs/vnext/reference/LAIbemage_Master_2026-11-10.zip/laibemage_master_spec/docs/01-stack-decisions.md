# 01 — Stack, versões e trade-offs

## Princípios
1. Postgres como fonte de verdade e base de filas; sem proliferação de bancos em P0.
2. TypeScript owns application/domain/interface; Python owns numeric ML/training/inference.
3. Contratos via OpenAPI + JSON Schema, geradores e testes; não compartilhar ORM entre linguagens.
4. Local-first significa **sem depender de APIs cloud** para o caminho de desenvolvimento, não ausência de serviços locais. Docker Compose permitido.
5. Escolher especializações por benchmark, não por entusiasmo. Componentes avançados são adaptadores opcionais.
6. Fixar versões de bibliotecas **no momento da implementação** (lockfiles e CI). Não considerar nomes/versões deste documento como matriz de compatibilidade testada.

## Stack essencial (P0/P1)
| Área | Escolha | Responsabilidade | Alternativas/gatilho |
|---|---|---|---|
| Monorepo TS | pnpm workspaces + Turborepo | tasks/cache/CI | Nx se graph complexo exigir |
| Runtime TS | Node.js Active LTS, TypeScript | API, SDK, CLI | sem Deno inicialmente |
| Frontend | Next.js App Router, React | Studio | Vite React se SSR não agregar; decisão a medir |
| UI system | Tailwind, shadcn/ui, Radix primitives | componentes acessíveis | design system próprio sobre primitives |
| Tabela/estado | TanStack Table/Virtual/Query, URL state | grids/servidor | não duplicar server state em Zustand |
| Anotação geométrica | Konva/react-konva (P1) | boxes/polygons | PixiJS/WebGL se milhares de formas |
| API | Fastify + Zod + OpenAPI | cases/validation | NestJS apenas se estrutura justificar |
| Auth local | loopback + token de sessão/OS | local-only | OIDC external no shared mode |
| Auth team | OIDC/OAuth2 + session/bearer, RBAC | colaboração | autorização por dataset/workspace |
| DB | PostgreSQL + Drizzle + migrações | source of truth | SQLite apenas futuro modo portátil após testes de paridade |
| Vetores | pgvector | visual search P1 | LanceDB quando scale/bench justificar |
| Full-text | PostgreSQL FTS | descrições/OCR | Elasticsearch só se relevância e escala exigirem |
| Imagens | filesystem CAS SHA-256 | originais e derivados | S3/MinIO por StoragePort |
| Jobs | pg-boss ou equivalente PG-backed | filas duráveis | Temporal para workflows complexos após evidência |
| ML service | Python 3.12, uv, FastAPI (para inference), CLI worker | execução de modelos | gRPC apenas se throughput exigir |
| ML/CV | PyTorch, scikit-learn, torchvision, timm, OpenCV, Pillow | treino/inferência | JAX opcional como pesquisa |
| Foundation/embedding | transformers, open_clip, sentence/vision encoders | representações | diferentes providers por capability |
| Training | MLflow Tracking, Optuna opcional | hyperparams/artefatos | W&B opcional se equipe optar |
| Data versions | snapshots do domínio + DVC para pesquisa | lineage Git/data | lakeFS se colaboração massiva |
| Analytics | DuckDB + Parquet | audit/análise offline | warehouse externo em escala |
| Inference | PyTorch / ONNX Runtime | CPU, MPS, GPU | TensorRT, Core ML para plataformas dedicadas |
| Agents | LangGraph + Pydantic | planning/checkpoint/approval | state machine simples primeiro |
| MCP | TS SDK v2 / spec 2026-07-28 | ferramentas para agentes | adapter legacy se clientes antigos |
| CLI | Commander.js + SDK | automation/developer | sem regras de negócio duplicadas |
| Telemetria | OpenTelemetry + logs estruturados | traces/metrics | Grafana/Tempo/Prom em perfil avançado |
| Testes | Vitest, pytest, Playwright, Hypothesis, contract tests | qualidade | mutation tests só em módulos críticos |
| Security | Dependabot/Renovate, secret scan, SCA, SBOM | supply chain | adicionar SLSA conforme release maturar |
| CI | GitHub Actions; artifact caching | gate/benchmark controlado | runners GPU próprios para GPU tests |
| Infra | Docker Compose dev/self-hosted | perfil local | K8s somente por capacidade/HA/GPU |

## Perfis
**Desktop local:** Node + Python + Postgres em Docker, CAS em diretório do usuário, modelos locais, execução opcional MPS. Sem auth remota, servidor preso a 127.0.0.1, sem chamadas cloud por default; a interface de navegador usa token de sessão.
**Team/self-hosted:** Postgres gerenciado pela organização, storage S3-compatível, OIDC, audit, worker pool, TLS. Falhas toleráveis e backup automatizado.
**Cloud/enterprise:** object store, métricas, pipelines de deploy, GPU pools isolados, tenancy e segurança, somente após demanda comprovada.

## Escolhas explicitamente adiadas
K8s, Kafka, microservices por domínio, Redis + outro sistema de filas, graph DB, data warehouse distribuído, feature store dedicada, multiple vector DBs, multiagent swarm, event sourcing total, fine-tuning de foundation models. Cada introdução deve apresentar benchmark/operational need e ADR.

## Compatibilidade e governança
- Pin exato em `pnpm-lock.yaml` e `uv.lock`; registrar Node/Python/CUDA/MPS compatíveis.
- Usar renovate com upgrade PRs, testes + contrato + benchmark antes de merge.
- Matriz CI macOS ARM64 e Linux CPU, e GPU linux se hardware disponibilizado.
- Verificar licenças de weights/modelos/datasets à parte do código; não pressupor que permissões de download permitam uso comercial.

## Fontes oficiais
- https://nextjs.org/docs/app
- https://fastify.dev/docs/latest/
- https://docs.astral.sh/uv/concepts/projects/workspaces/
- https://docs.pytorch.org/docs/stable/notes/mps.html
- https://www.mlflow.org/docs/latest/tracking/
- https://doc.dvc.org/user-guide/pipelines/defining-pipelines
- https://onnxruntime.ai/docs/execution-providers/
- https://ts.sdk.modelcontextprotocol.io/v2/
- https://modelcontextprotocol.io/specification/2026-07-28
