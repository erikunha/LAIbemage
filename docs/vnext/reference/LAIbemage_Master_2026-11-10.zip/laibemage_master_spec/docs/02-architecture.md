# 02 — Arquitetura lógica e de execução

## Visão C4: Context / Containers
```mermaid
flowchart TD
  U[ML Engineer / Annotator / Dev] --> S[Studio Next.js]
  U --> C[CLI / SDK]
  A[External AI Client] --> M[MCP adapter]
  S --> API[Fastify API - application services]
  C --> APP[Application SDK/use cases]
  M --> APP
  API --> APP
  APP --> DB[(PostgreSQL + pgvector)]
  APP --> CAS[(Content-addressed artifact store)]
  APP --> Q[Postgres-backed jobs]
  Q --> W[TS job worker]
  W --> P[Python ML worker]
  P --> EXP[(MLflow experiments)]
  P --> CAS
  APP --> OT[OpenTelemetry]
  W --> OT
  P --> OT
```

## Bounded contexts
1. **Identity/Workspace:** tenants, roles, scopes, permissions, audit.
2. **Asset Catalog:** upload, CAS, media/metadata, renditions, cleanup.
3. **Dataset & Ontology:** dataset, membership, immutable snapshots, splits, category schemas.
4. **Annotation:** human review, versions, geometry, agreement, tasks.
5. **Prediction & Search:** model outputs, embeddings, indexes, filters.
6. **Experiment & Evaluation:** specs, training jobs, gold set, metrics/artifacts.
7. **Model Registry & Deployment:** immutable model versions, approval, serving config.
8. **Agent & Automation:** plans, executions, constraints, tool invocations.
9. **Operations:** jobs, outbox, usage, metrics, policy, billing-ready cost ledger (not billing engine).

All use cases enforce authorization and tenancy before DB/storage access. No direct DB from browser, MCP or model.

## Code dependency direction
`apps/* → packages/application → packages/domain`. Infra adapters depend on ports in application. Python tasks depend on serialized versioned contracts, never import JS. Cross-boundary calls use typed DTOs and contract tests. Avoid making a generalized workflow DSL before 2 real workflows.

## Ingestion sequence
```mermaid
sequenceDiagram
  participant C as CLI/Studio
  participant A as API
  participant D as Postgres
  participant S as Asset Store
  participant J as Job worker
  C->>A: POST /v1/assets/upload-intents (name,size,sha256,mime)
  A->>D: validate workspace, quota, rights
  A-->>C: short-lived upload intent
  C->>S: upload (filesystem API or signed URL)
  C->>A: finalize upload, idempotency key
  A->>S: verify hash/media header
  A->>D: commit asset metadata and audit
  A->>D: enqueue outbox/job
  J->>S: create thumbnails / metadata
  J->>D: save derived artifacts & progress
```

## Training sequence
```mermaid
sequenceDiagram
  participant U as User/Agent
  participant API as API
  participant DB as Postgres
  participant Q as Jobs
  participant P as Python worker
  participant ML as MLflow/CAS
  U->>API: request experiment against snapshot id
  API->>DB: authorize + validate split/quotas
  API->>DB: create run + idempotency record
  API->>Q: enqueue
  Q->>P: launch restricted job with artifact handles
  P->>ML: metrics/checkpoints/structured result
  P->>DB: progress/status via controlled interface
  P-->>Q: terminal status
  API-->>U: results linked by immutable run id
```

## Jobs lifecycle
`QUEUED → CLAIMED → RUNNING → SUCCEEDED | FAILED | CANCELED | TIMED_OUT`. Claim with lease; heartbeat; worker preemption expires lease; bounded retry if transient; reentrant tasks must use idempotent output artifact keys. Idempotency token unique per tenant, route, payload fingerprint, with TTL and exactly one canonical run. Exponential backoff + jitter; poison job into dead-letter with manual requeue; no automatic retry of destructive work. Cancel requests set `cancel_requested` then signal worker; report exact terminal state.

## Consistency
Postgres transaction commits metadata + outbox; worker dispatch asynchronously. For CAS object writes, stage temp file, verify SHA-256 and atomic rename; commit metadata referencing verified blob. Garbage collection delayed and driven by reachability; never delete original on a failed DB transaction before recovery reconciliation.

## External boundaries
- User-supplied URLs/images: untrusted; only allowlist schemes/host/IP with SSRF protections; decode in resource-limited process.
- Provider models: adapter with capability manifest, rate limits, timeout/retry, budget, privacy policy.
- Agent tools: scoped app cases, not database access, shell or arbitrary Python.
- Remote mode: TLS/identity, per-request authorization, audit records.

## Architecture characteristics
- Durability: DB + artifacts survive process crash, jobs can resume or restart without corrupting state.
- Local parity: the same app cases run locally; enterprise additions are policies/storage/runtime adapters, not forks of core logic.
- Observability: `request_id`, `job_id`, `asset_id`, `dataset_snapshot_id`, `experiment_run_id`, `trace_id` propagate end-to-end.
- Isolation: training/inference tasks have CPU/GPU/memory/time/IO limits; ML service cannot access arbitrary user directories.

## Target architecture evolution
**M0:** modular backend + PG + local filesystem + subprocess Python, no separate online serving.
**M1:** independent job workers / FastAPI inference service, MLflow, pgvector, OTel.
**M2:** remote object storage, OIDC, job scheduling/pools, autoscale.
**M3:** dedicated GPU orchestration, model canary/shadow, multitenancy; only by evidence.
