# 03 — Modelo de domínio, identificadores e lineage

## Terminologia (proibido conflar)
- **Asset:** bytes originais; SHA-256, mime, origem, licença, consentimento e metadata. Imutável.
- **Rendition:** derivado (thumbnail, crop, redacted copy, mask visualization) ligado ao Asset/Transform.
- **Sample:** unidade de aprendizagem: asset inteiro, frame, crop ou clip; tem coordenadas/frame e grupo de captura.
- **OntologyVersion:** snapshot de classes, atributos, relações, taxonomia e regras de anotação.
- **Annotation:** afirmação de revisor/ground truth, com autoria, proveniência, status e geometria. Versões append-only.
- **Prediction:** saída de `ModelVersion` sob `InferenceConfig`. Nunca é annotation nem ground truth.
- **DatasetSnapshot:** manifesto imutável de samples + annotations fixadas + ontology + split policy.
- **ExperimentRun:** tentativa de treinamento/teste sob configuração e hardware fixados.
- **EvaluationRun:** score contra versão gold com protocolo, thresholds, outputs e intervalos.
- **ModelVersion:** weights/checksum/preprocess/calibration/runtime/licença e registro.
- **AgentRun:** objetivo, plano, tool calls, checkpoints, evidências, limites e decisão.

## Identificadores
UUIDv7/ULID (ordenáveis) para entidades de domínio, SHA-256 para bytes e fingerprints de payload, UUID para traces. IDs opacos, jamais paths internos ou tokens. Prefixos legíveis em logs (`ast_`, `ds_`, `snap_`, `mod_`, `run_`), mas schema de ID é responsabilidade do contrato.

## Entidades relacionais
`workspaces → datasets → dataset_snapshots → snapshot_samples → samples → assets`. Outras: ontology_versions, annotations, annotation_reviews, model_versions, predictions, embeddings, experiment_runs, evaluation_runs, jobs, job_events, artifacts, lineage_edges, approval_requests, audit_events, usage_events, licenses.

`contracts/reference_postgres.sql` é um **subset inicial** do modelo; implementar migrações antes de uso. Ele não cobre todos os domínios futuros.

## Regras de integridade
1. Um asset original é CAS por hash; importação repetida resulta no mesmo blob, mas pode produzir vínculos distintos ao workspace/dataset.
2. DB não armazena imagem em base64/bytea; usa URI lógica de StoragePort + hash; DB só metadata.
3. Versionamento: alterações de anotação criam revisão com `supersedes_annotation_id`; não reescrever fatos passados.
4. Gold label requer `approved` e protocolo de adjudicação; prelabels de IA nunca entram no gold automaticamente.
5. Snapshot é criado após validações e contém `manifest_sha256`. Sem alterações posteriores de membros/rótulos/splits.
6. `dataset_snapshot_id` obrigatório em training/eval. `model_version_id` sempre identifica pesos/preprocessing/ontology.
7. Split antes de augmentation, por grupo (capture session/equipment/location) e próximo-duplicado; gold de teste deve permanecer cego à seleção/treino.
8. `Prediction` tem modelo, artifact hash, timestamp, prompt/model configuration, score bruto e opcional calibrated score. Scores de arquiteturas diferentes não são diretamente comparáveis.
9. Retenção e exclusão: política por workspace, exclusão lógica seguida de GC seguro respeitando bloqueios legais/linhagem; dados em backups têm prazo específico.
10. Não armazenar PII em logs e prompts indiscriminadamente; EXIF GPS é sensível.

## Snapshot canonical manifest (semântica)
```
manifest_version: 1
snapshot_id: snap_xxx
ontology_version_id: onto_v3
split_policy: group_stratified_v1
samples:
  - sample_id: sam_01
    asset_sha256: <hex>
    annotation_revision_ids: [ann_42]
    split: train
    capture_group_id: equipment-a/session-1
```
Serialize com canonical JSON, ordenar deterministicamente e calcular SHA-256. Data repository deve fornecer a mesma lista por digest no futuro. Não embutir segredo nem paths absolutos no manifest.

## Propostas de tipos de anotação
- `classification`: label IDs + atributos opcionais, whole sample.
- `detection`: bbox x/y/w/h + unidade explícita (`relative` ou `pixels`), orientação/rotação.
- `segmentation`: mask as artifact reference (RLE/PNG) ou polígono com pontos.
- `keypoints`: pontos nomeados, skeleton/version, visibility.
- `ocr`: boxes + texto + language + leitura/estrutura.
- `temporal`: time intervals, track IDs, relations, sensor timestamps.
Usar discriminated union por `task_type` (ver `contracts/annotation.schema.json`).

## Índices e análise
B-tree: workspace, dataset, status, timestamp. pgvector: vetores com `embedding_model_id`, `dimensions`, `normalization`, `preprocess_hash`, `asset/sample_id`; proibido misturar espaços semânticos. Consulta ANN deve medir Recall@K vs brute force. Use DuckDB/Parquet para relatórios grandes e resumos; não tornar dados analíticos a fonte de verdade.

## Data lineage graph
`Raw asset → transformed sample → annotation revision → dataset snapshot → training run → model version → evaluation run → deployment → production feedback`. Cada aresta tem `source`, `target`, `relation`, `actor`, `timestamp`, `code_revision`, `parameters_sha`. Usuário pode percorrer lineage e reproduzir.
