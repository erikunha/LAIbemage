# 04 — Ingestão, curadoria, anotação e visual search

## Pipeline de ingestão
1. Criar intenção autenticada e validar quota por workspace, tipo e tamanho.
2. Transferir bytes em chunks; staging com limite de tempo/armazenamento.
3. Verificar hash SHA-256, magic bytes, mime/codec, dimensões, pixel count e decodificação.
4. Extrair metadados em processo limitado; EXIF GPS opt-in/strip por política.
5. Deduplicar por hash exato, pHash/dHash como sugestões de near-duplicate; nunca deletar por similaridade automática.
6. Persistir asset + origem + licença + timestamp/capture_group.
7. Gerar derivados com versioned transform spec (thumbnail, tile, preview, safe redaction).
8. Registrar evento e métricas; falha de um arquivo não invalida lote inteiro sem política explícita.

## Video P2
Captura como sequência com `video_id`, FPS real/variável, codec, time base, keyframe, intervals, camera_id, sync_clock. Amostragem adaptativa de frames com rastreabilidade frame->timestamp; não tratar vídeo como lista desordenada de JPGs. Decodificação em sandbox com limites. Multi-camera e sensores exigem calibração e incerteza temporal.

## Data quality algorithms
- Corrupt: libvips/Pillow decode; pixel bomb guard.
- Exact dup: SHA-256; near dup: perceptual hash e confirmação visual.
- Leakage: comparar hashes/embeddings e grupos de captura entre train/val/test; alertas antes de freeze.
- Noise: blurry (variância Laplaciana como heurística), over/under-exposed, cropped objects; calibrar por domínio.
- Class imbalance: histogramas, effective sample sizes, rare slices, missing stratification.
- Outlier: embedding distance/local density (kNN/LOF) como sugestão, nunca exclusão automática.
- Label issues: disagreement model/human, high-loss examples, uncertainty ensemble, QA sample; indicar hipótese e evidência.
- Dataset shifts: distance/PSI/MMD por features com teste de significância por janela e controle de falso alerta.

## Annotation workflow
`unlabeled → AI_suggested → assigned → in_review → approved | disputed → adjudicated → frozen`.
Usuários enxergam separação entre AI suggestion e revisão humana. Every edit creates revision; user and timestamp recorded. Controle de bloqueio otimista via `version`/ETag para edições concorrentes. Review samples intercalados para concordância; dispute queue para inter-annotator disagreement e guideline updates.

## Annotation UI
- Classificação via teclado, batch actions, filtros por classe e score.
- Detecção: canvas, bounding box, resize, rotated boxes, constraints, zoom/pan, shortcut.
- Segmentação: polygon, brush, mask assist, zoom, separação raster/vector.
- OCR: regiões, transcrição, ordem de leitura, tabelas e página.
- Vídeo: frames, timeline, tracks, interpolação, keyframes; P2.
- QA: blind review, consensus, adjudication, reviewer-specific statistics, audit history.

## Formatos e interoperabilidade
COCO detection/segmentation, YOLO detection (boxes txt), YOLO classification (directories per split/class), Pascal VOC, CVAT, Label Studio e JSONL nativo; explicit task-specific export and class mapping. Não exportar caixas artificiais full-image como se fossem labels válidos de object detection. Documentar coordenadas (pixel vs normalizada), origem, EXIF orientation, masks e IDs.

## Active learning
Estratégias: entropy/margin, ensembles/disagreement, diversity(k-center), representativeness, coverage of rare slices, aleatoriedade estratificada de baseline, cost-aware review. Medir ganhos após adicionar exemplos ao **train** e validar em holdout não tocado. Evitar reinforcement de rótulos incorretos; revisar prelabels independente; registrar budget e política de aquisição.

## Busca multimodal
Consulta texto→imagem (encoder comum text-image); imagem→imagem; filtros `workspace,dataset,split,timestamp,ontology,class`; FTS para OCR/descrições; hybrid rank fusion com scores normalizados/rrf. Índices versionados por embedding model+preprocess; reindex incremental. Avaliar retrieval Recall@K, nDCG, latency p50/p95 e recall ANN vs exato. Cuidado: uma imagem com legenda gerada não substitui pixel embedding.

## Eventos
`asset.ingested.v1`, `asset.processing_failed.v1`, `annotation.created.v1`, `annotation.approved.v1`, `dataset.snapshot_created.v1`, `dataset.quality_reported.v1`. Events pelo outbox com schemaVersion, tenant, aggregateId, trace_id; consumidores idempotentes.

## Edge cases
- Se EXIF/timestamp ausente: `timestamp_source=unknown`, jamais inventar data.
- Falha no reconhecimento: marca como `unknown`, não forçar classe.
- Arquivos duplicados entre workspaces: bytes podem compartilhar store físico somente se permissões/criptografia/retention permitirem; não há acesso cruzado.
- Dataset licenciada para pesquisa: não pode ser promovido automaticamente para oferta comercial.
