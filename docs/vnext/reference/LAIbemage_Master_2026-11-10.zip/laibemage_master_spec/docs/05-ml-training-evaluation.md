# 05 — Engenharia de ML, treinamento, avaliação e otimização

## Princípio científico
Comparar modelos significa comparar **tarefas iguais, dados equivalentes, métricas corretas e infraestrutura/hardware registrados**. VLM, classifier, detector e anomaly detector não devem entrar na mesma tabela de accuracy sem converter para tarefa/protocolo comum. O sistema de inferência nunca deve atualizar gold labels silenciosamente.

## Taxonomia de tarefas
| Task | Input | Output | Métricas primárias |
|---|---|---|---|
| Multiclass classification | imagem | uma classe | macro F1, recall por classe, balanced accuracy |
| Multilabel classification | imagem | conjunto de classes | mAP, macro/micro F1, per-label PR |
| Detection | imagem | boxes + scores/classes | mAP@[.5:.95], recall por classe, IoU |
| Segmentation | imagem | máscaras/polígonos | mIoU, Dice, AP masks, boundary metrics |
| Anomaly detection | imagem | score/heatmap | AUROC/AUPRC com desbalanceamento exposto, FPR@TPR |
| OCR / extraction | imagem/documento | texto/campos | CER/WER, field exact match, groundedness por region |
| Retrieval | imagem/texto | ranking | Recall@K, mAP, nDCG, latency |
| Video/event | clip | temporal segment/track | temporal IoU, event F1, tracking HOTA/IDF1 |
| Visual QA | image+question | resposta/evidência | exact/fact agreement, grounding, abstention |

## Linha base: ordem de experimentos
1. Random/majority class + hand-crafted baseline para detectar leakage/desbalanceamento e evitar overclaim.
2. Encoder congelado (CLIP/SigLIP/DINO) + logistic regression/SVM/scikit-learn; custo muito baixo, separa qualidade do embedding.
3. Transfer learning CNN/ViT (freeze backbone vs finetune head vs partial unfreeze); controle de seeds e schedules.
4. VLM zero-shot/few-shot com structured output e política de abstention. Medir prompt/model, temperatura, versões e custo.
5. Cascata local→modelo mais caro→humano com thresholds calibrados em **validation**, não no test.
6. Active learning em lotes: seleção vs amostragem aleatória; curva performance vs # rótulos / horas de revisão.
7. Detecção/segmentação/anomalia P1 conforme dataset e hardware; treino de grandes VLMs P2.

## Training specification (JSON/YAML contract)
Requisitos mínimos: `experiment_name`, `task_type`, `snapshot_id`, `ontology_version_id`, `model_source`, `model_revision`, `preprocessing`, `augmentation`, `seed`, `optimizer`, `scheduler`, `training_epochs`, `batch_size`, `compute_profile`, `budget`, `early_stopping`, `eval_protocol_id`, `artifact_retention`. Veja `examples/experiment.yaml`.

## Data splits e leakage
- Split imutável por group_id/equipment/site/time/capture_session quando correlação. Próximos-duplicados não cruzam splits.
- Stratification condicionada a group leakage; métricas por classe / dispositivo / condições de luz / localização.
- Train apenas para adaptação; validation para tuning de hyperparams/calibração/threshold; test lacrado para release e avaliação final.
- Holdout OOD e adversarial/perturbation para degradações plausíveis, sem confundir com teste representativo.
- Bootstrap confidence intervals por **grupo independente**, não por pixels/frames correlacionados.
- Registrar leakage scan e aceitar exceções somente com justificativa.

## Tracking e reproducibilidade
Um `ExperimentRun` deve capturar: git commit, diff status, pip/uv lock digest, dataset manifest SHA, ontology SHA, weights checksum, hardware info (CPU/GPU/MPS), precision, batch, seed, config, preprocessing pipeline, transforms/augmentations, thresholds, calibration method, metrics, artifacts e wall-time. MLflow registra runs/artefatos; domínio armazena FK e lineage. DVC vincula dados versionados ao código durante pesquisa.

**Determinismo:** documentar limitações de kernels/CUDA/MPS. Seeds não garantem bitwise reproducibility em todo hardware. Pass rate deve comparar tolerâncias e invariantes, não bytes idênticos de modelos treinados em diferentes dispositivos.

## Evaluation engine
1. Resolver snapshot e ModelVersion; validar compatibilidade input/task/ontology.
2. Executar conjunto congelado e não exposto ao tuner.
3. Registrar prediction por sample com latência e abstention.
4. Calcular métricas com denominadores e intervalos; salvar confusion matrix e failure slices.
5. Calibrar confidence em validation separado (temperature, isotonic, Platt ou conformal se cenário permitir); avaliar ECE, Brier, reliability plots.
6. Executar robustness slices (blur, baixa luz, mudanças de sensor) como conjuntos separados; distinguir sintético de real.
7. Medir throughput, RSS/GPU memory, peak VRAM, warm/cold start, p50/p95/p99, cost e energia opcional.
8. Comparator produz deltas pareados e IC, não só tabela de averages; destaca regressões em classe crítica.
9. Release gate verifica hard constraints e pede aprovação. Sem inventar certeza estatística a partir de datasets pequenos.

## Promotion policy (exemplo, nunca universal)
```
critical_class_recall_lower_ci >= 0.95
macro_f1_delta_lower_ci >= -0.01
p95_latency_ms <= 300
missing_prediction_rate <= 0.001
safety_evals == pass
license_gate == pass
```
A política numérica deve ser revisada por stakeholders do domínio, com dimensão de amostra e risco definidos. Defaults conservadores: abstain/review em classes críticas quando calibração for insuficiente.

## Cost and model routing
Predizer custo por tarefa corretamente concluída; registrar tokens/inference per model, compute, human review, retries, cache hits e desperdício. Estimar `expected_total_cost = compute + review + expected_error_cost`, considerando penalidades distintas para falso positivo/negativo. Construir fronteira de Pareto (quality, cost, latency, coverage). Routing policy deve ser avaliada como modelo próprio: calibrar política no validation, teste final cego e acompanhamento em produção.

## Model registry / deployment
Model artifact = weights + safe file format + preprocess graph + class mapping + calibration + eval fingerprint + license + model card + code commit + runtime requirements. Alias `candidate/champion/rollback`, nunca altere bytes sob um mesmo model version. Promotion: draft→review→approved→deployed→retired. Shadow/canary somente após monitor e rollback.

## Métricas de progressão do projeto
- Reproduzir linear probe vs VLM em dataset de inspeção real.
- Cada métrica tem dataset snapshot, protocolo, denominador e run id.
- Revisão humana gera annotation revision verificável e retorno ao treinamento.
- Demonstrar curva cost-quality sob restrições de recall.
- Executar ablation da seleção ativa vs random.

## Ferramentas e docs
- PyTorch transfer learning: https://docs.pytorch.org/tutorials/beginner/transfer_learning_tutorial.html
- MLflow: https://www.mlflow.org/docs/latest/tracking/
- DVC: https://doc.dvc.org/user-guide/pipelines/defining-pipelines
- ONNX Runtime: https://onnxruntime.ai/docs/execution-providers/
