# 06 — REST API, contratos e jobs

## Princípios da API
- Base `/v1`, JSON UTF-8, datas ISO 8601 UTC, ids opacos; OpenAPI gerado a partir dos schemas de validação, teste de contract drift.
- Auth: perfil local usa token de sessão loopback, team usa OIDC JWT/sessions e scopes por workspace. Roles: `owner`, `admin`, `ml_engineer`, `annotator`, `reviewer`, `viewer`; escopo por dataset pode restringir role.
- Sempre validar workspace_id e relações de entidade. Nunca confiar em ids fornecidos pelo agente.
- Erros `application/problem+json` estilo RFC 9457, `type,title,status,detail,instance,request_id`. Sem stack traces ou paths internos.
- Listas paginadas por cursor estável, limites de `page_size`, ordenação determinística. Filtros com índices.
- Rotas de criação de job recebem `Idempotency-Key`, `expected_dataset_snapshot_version` quando relevante. Chave + fingerprint por tenant/route.
- Mutations com ETag/If-Match e auditoria; optimistic concurrency em annotations/ontology.
- Payloads grandes: upload intents / presigned URL / streaming; não base64 JSON.
- Tasks longas: `202 Accepted`, `job_id`, `Location: /v1/jobs/{id}`. Polling; SSE opcional para progresso, eventos versionados. Expor cancelamento por endpoint.

## Endpoints P0
| Método | Rota | Autorizações | Semântica |
|---|---|---|---|
| POST | `/v1/datasets` | dataset:write | cria dataset sem rótulos |
| GET | `/v1/datasets` | dataset:read | lista por workspace |
| GET | `/v1/datasets/{id}` | dataset:read | detalhes, status, lineage |
| POST | `/v1/assets/upload-intents` | asset:write | reserva upload/hash/limites |
| POST | `/v1/assets/{assetId}/finalize` | asset:write | valida e registra asset |
| POST | `/v1/datasets/{id}/assets:attach` | dataset:write | vincula assets após validação |
| GET | `/v1/datasets/{id}/samples` | dataset:read | pagina/filter |
| POST | `/v1/datasets/{id}/audit-jobs` | eval:run | audit idempotente |
| POST | `/v1/datasets/{id}/snapshots` | dataset:freeze | cria snapshot imutável |
| GET | `/v1/jobs/{jobId}` | job:read | estado/progresso/erro seguro |
| POST | `/v1/jobs/{jobId}:cancel` | job:cancel | idempotente, best-effort |
| GET | `/v1/artifacts/{id}/download-intent` | artifact:read | URL expira/escopo |

## Endpoints P1
| Método | Rota | Permissão | Semântica |
|---|---|---|---|
| POST | `/v1/annotations` | annotation:write | nova revisão, origem humana/IA |
| POST | `/v1/annotations/{id}:approve` | annotation:approve | approve/QA |
| POST | `/v1/embeddings/jobs` | embedding:run | indexar snapshot com modelo |
| POST | `/v1/search` | dataset:read | busca imagem/texto + filtros |
| POST | `/v1/experiments` | experiment:run | treino/avaliação (async) |
| GET | `/v1/experiments/{id}` | experiment:read | resultados/artefatos |
| POST | `/v1/evaluations` | eval:run | eval contra gold snapshot |
| GET | `/v1/evaluations/{id}` | eval:read | métricas + per-sample |
| POST | `/v1/evaluations:compare` | eval:read | delta + bootstrap |
| GET | `/v1/models` | model:read | model registry |
| POST | `/v1/models/{id}:propose-promotion` | model:promote | approval request |
| POST | `/v1/agents/investigations` | agent:run | plano read-only/experimental |
| POST | `/v1/approval-requests/{id}:decide` | approval:decide | aprovar/negar após display |

## Exemplo — job creation
Request:
```http
POST /v1/experiments HTTP/1.1
Authorization: Bearer <redacted>
Idempotency-Key: 5f8c292c-ea03-40e3-9f49-b6a01ca14812
Content-Type: application/json

{"workspace_id":"00000000-0000-4000-8000-000000000001","dataset_snapshot_id":"00000000-0000-4000-8000-000000000005","experiment_spec_id":"00000000-0000-4000-8000-000000000006","budget":{"max_usd":10,"max_wall_seconds":1800}}
```
Response:
```json
{"job_id":"00000000-0000-4000-8000-000000000009","status":"queued","result_url":"/v1/jobs/00000000-0000-4000-8000-000000000009"}
```

## Error codes
`VALIDATION_FAILED`, `UNAUTHORIZED`, `FORBIDDEN`, `NOT_FOUND`, `CONFLICT_VERSION`, `QUOTA_EXCEEDED`, `BUDGET_REJECTED`, `MODEL_INCOMPATIBLE`, `DATASET_NOT_FROZEN`, `LICENSE_DENIED`, `JOB_NOT_CANCELABLE`, `PROVIDER_UNAVAILABLE`, `INTERNAL_ERROR`. `retryable` true only where appropriate; retry with backoff on transport/server errors and rate-limit.

## Internal contract TS/Python
- `JobSpec` versioned and validated; Python receives a reference to a JSON manifest + short-lived capability to read referenced artifacts, **not** direct arbitrary paths.
- Python worker writes structured JSON Lines progress (`type=progress|metric|artifact|terminal`, `job_id`, `seq`, `schema_version`, payload) or posts to controlled internal endpoint; no raw stdout logs interpreted as trusted code.
- ML output must include `model_artifact_digest`, `dataset_snapshot_id`, `experiment_spec_hash`, `metrics`, `cost_usage`, `source_revision`, `reproducibility_status`, `errors`.
- No infinite nesting, model-tool generated arbitrary schemas or unrestricted filesystem.
- Contract tests exercise serialization, invalid payload rejection, cross-language equality and backwards compatibility.

## Pagination and performance
Use seek/keyset over sort+id; explicit `filter` allowlist; `page_size` capped (e.g. 100). For visual gallery return previews + metadata and signed media URLs, not original bytes. Exports become async artifact jobs rather than 5GB HTTP responses.

## Reference artifacts
- `contracts/openapi.yaml` subset valid OpenAPI 3.1.
- `contracts/job.schema.json` proposed versioned wire contract.
- `contracts/reference_postgres.sql` subset relational.
