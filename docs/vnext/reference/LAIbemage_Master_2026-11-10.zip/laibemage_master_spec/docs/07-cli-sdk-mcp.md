# 07 — CLI, SDKs, Model Context Protocol

## CLI
CLI chama os mesmos application use cases da API, por adaptador local ou remoto. Preserve o executável publicado `ai-image-labeling` como alias/compatibilidade; migração gradual para `laib`, com telemetria opt-in e mensagens de depreciação. Não alterar flags silenciosamente.

### Proposta de comandos
```bash
laib init --workspace local
laib dataset create inspection --ontology ./schemas/defects.yaml
laib dataset ingest inspection ./photos --recursive --dry-run
laib dataset audit inspection --profile quality
laib dataset snapshot inspection --group-by capture_session
laib images search inspection --text 'corrosion' --top-k 20
laib annotations review inspection --queue uncertain
laib embed run inspection --model siglip2 --device auto
laib eval run --snapshot snap_... --model mod_... --config ./examples/eval.yaml
laib train run --config ./examples/experiment.yaml --budget-usd 10
laib experiments compare run_1 run_2
laib agent investigate 'Why is critical recall down?' --read-only
laib mcp serve --transport stdio
laib studio start --bind 127.0.0.1
```
Esses comandos **não existem ainda**. Os subcomandos leem `--help`, aceitam `--json`, `--quiet`, `--verbose`, `--dry-run`, `--config`, `--profile`, `--timeout`; exit codes 0 success, 2 invalid input, 3 auth, 4 partial, 5 runtime/provider, 130 SIGINT. Não inventar output e exit code diferente entre sistemas. Comandos destrutivos exigem `--confirm` ou prompt TTY, jamais `--yes` por default.

## TypeScript SDK
Clientes tipados gerados do OpenAPI para API; `@laibemage/client` para operações remotas e `@laibemage/core` para use cases locais, sem duplicação. API pública versionada semver; DTOs no pacote contracts; importações internas `src/*` não são estáveis. API aceita `AbortSignal`, pagination iterators, retries *somente* idempotentes, context tracing e auth injection. Nunca expor path absoluto local na API remota.

## Python SDK
`laib_client` gerado ou camada manual mínima para modelos e notebooks: list datasets, get snapshot, fetch artifact via capability token, submit eval, publish metrics. Model adapters seguem `VisionModelProtocol` (model metadata, tasks, preprocess, infer, batch, warm-up). Python SDK não oferece bypass à policy server-side.

## MCP — protocolo 2026-07-28
Especificação estável: https://modelcontextprotocol.io/specification/2026-07-28 ; SDK TS v2: https://ts.sdk.modelcontextprotocol.io/v2/. Esta versão é **stateless**, cada request carrega informações de versão/capabilities conforme especificação. Não assumir `initialize`/sessão como no protocolo anterior. Compatibilidade com versões `2025-11-25` e anteriores deve ser negociada/implementada em adapter separado conforme SDK.

### Transportes
- **stdio local (P1):** processo filho lançado por IDE/agent client; única saída `stdout` são mensagens MCP; logs stderr; restringir workspace e roots explicitamente. Ferramentas apenas allowlisted.
- **Streamable HTTP (P2):** auth por request, scopes, TLS, origin/host validation e rate limits; sem armazenar credenciais em session state; CORS não substitui authorization.
- Todas ferramentas usam contratos typed com `inputSchema`, output estruturado e erros definidos; ordem de ferramentas determinística para cache de contexto.

### Tool catalog (proposta)
| Tool | Scope | Efeito | Política |
|---|---|---|---|
| `datasets_list` | dataset:read | read | livre no escopo |
| `dataset_inspect` | dataset:read | read | livre no escopo |
| `dataset_audit` | eval:run | enqueue | quota/budget |
| `images_search` | dataset:read | read | filtragem por workspace |
| `sample_get` | dataset:read | read | metadados sem bytes privados |
| `evaluation_compare` | eval:read | read | somente run autorizado |
| `experiment_plan` | experiment:read | read | sem executar |
| `experiment_submit` | experiment:run | enqueue | aprovação de custo/compute |
| `annotation_batch_propose` | annotation:write | proposal | revisável |
| `model_promotion_propose` | model:promote | proposal | não promove |
| `jobs_status` | job:read | read | id token vinculado ao workspace |
| `report_generate` | report:generate | enqueue | limite de dados/custo |

### Handles & long-running operations
No moderno stateless, tool returns `job_id`/`artifact_id` com escopo de usuário, não status mantido em conexão. `jobs_status` verifica permission a cada chamada. Sem tool para `run_shell`, `eval_python`, SQL arbitrário ou `delete_all`. Há limite de tokens, imagens, tempo e chamadas por agent run.

### Resources e prompts
Resources expõem `dataset://workspace/<id>/snapshot/<id>`, `model://...`, `evaluation://...` com mime/metadata e auth. Evitar raw imagens privadas por default. Prompts versionados como `investigate_model_regression`, `compare_cost_quality`, `propose_annotation_batch` são *templates* e nunca autoridade de execução.

### Evals do MCP
- Validação JSON Schema e respostas previsíveis.
- Redteam: prompt injection em OCR/EXIF/filenames; path traversal; forged workspace ids; exfiltration by URL; runaway loops.
- Cancelamento e timeouts; no duplicate job under retry; intents com approvals reais.
- Testes de compatibilidade com 2 clientes reais + sdk mock.

## Observabilidade
Cada call inclui `tool_name, actor, workspace, job_id, trace_id, bytes, cost` sem dados privados. `tool_input` logado somente com redaction/allowlist. Os resultados mantêm `schema_version`, `status`, `result`, `artifact_handles` e `diagnostic_refs`.
