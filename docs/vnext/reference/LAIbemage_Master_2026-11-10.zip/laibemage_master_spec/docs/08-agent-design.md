# 08 — Agentic Visual Engineering

## Tese arquitetural
Agente é uma **interface de planejamento e investigação**, não a camada de autoridade. ML training, métricas, segurança, orçamento e persistência são serviços determinísticos. Priorizar um agente único e ferramentas tipadas; multi-agentes precisam demonstrar ganho em benchmark.

## Grafo LangGraph proposto
```mermaid
flowchart TD
  I[Input + actor + policies] --> N[Normalize task]
  N --> T[Read-only triage & scope]
  T --> P[Plan hypotheses/tools]
  P --> V[Validate budgets/scopes]
  V --> G{Approval required?}
  G -->|yes| H[Human interrupt]
  G -->|no| E[Execute bounded tools]
  H -->|approved| E
  H -->|denied| R[Safe refusal/alternative]
  E --> O[Observe tool results]
  O --> C[Deterministic checks + evidence verification]
  C --> D{Enough evidence?}
  D -->|no, under budget| P
  D -->|yes, or limit| F[Final evidence report]
```

## Agent state
```
AgentState = {
  run_id, actor_id, workspace_id, goal, task_type,
  approved_scopes, dataset_snapshot_refs, model_refs,
  max_tool_calls, max_tokens, max_usd, deadline,
  plan_version, plan_steps, observations, evidence_refs,
  pending_approval_id, used_budget, error_state,
  checkpoints, trace_id
}
```
State persiste em checkpointer, mas autorizações revalidadas por tool call. Long-term memory só armazena fatos confirmados com provenance, não instruções de arquivos externos ou inferências apresentadas como fato. Retenção configurável.

## Tools permitidas
Leitura: metadata, dataset quality, evaluation runs, model registry, search, retrieve sample, compare. Escrita limitada: submit job, annotation proposal, generate report. Mutation sensível: train > budget, change ontology, deploy, external upload, delete => approval explicit.

## Evidence contract
Cada afirmação factual vem de `EvidenceRef` com `type, resource_id, version, sample_id/region/time, source_run, confidence_kind`. Exigir distinção: `observed_metric`, `model_prediction`, `human_label`, `agent_hypothesis`. Agent cannot cite itself as source. Verifier confere existência, acesso, consistência das métricas, unidade e limiares; VLM judge apenas complemento, não única evidência.

## Prompt injection / tool abuse
Entrada de OCR, legendas, arquivos e EXIF é **data**, nunca system prompt. Filtros e serialização de ferramenta sem execução de strings. Prevent model from selecting arbitrary internal resources via ID guessing. Deny outbound network/URL browsing from workers except allowlisted; no environment secrets in tool results. Rate/iteration ceilings, prompt/token budgets and loop breaker; kill on policy escalation.

## Orquestração de experimentos
Antes de executar, agent gera `ExperimentProposal` com baseline, hipótese refutável, expected result, cost, wall time, compute profile, dataset snapshot id, eval protocol, accepted risk. UI mostra plano/changes; executor exige approval token específico ao fingerprint da proposta. Alterações à proposta invalidam aprovação. Experimentos são reproduzíveis por run.

## Agents que podem surgir depois
- Dataset Auditor (qualidade/leakage)
- ML Experiment Scientist (ablation/hypothesis)
- Cost Optimizer (quality-cost Pareto)
- Release Guardian (gates/rollback recommendation)
- Incident Investigator (drift/regressões)
Evitar atribuir entidades separadas antes de existir teste que prove utilidade.

## Avaliação de agentes
Golden tasks com ferramentas mock e reais; medir `task_success`, grounded claims, correct tool trajectory/equivalence, cost/tokens, tool-call count, policy violation rate, approval compliance, retry behavior, timeout/loop, consistency across seeds. Comparar:
A) deterministic workflow sem LLM; B) agente com tools; C) agente com verifier; D) opcional multiagent. Reportar IC e casos com falha. Benchmarks offline por default; live API tests opt-in e dentro do orçamento.

## Resumo seguro / UX
Exibir trace estruturado: goal → plan → tools → metrics → evidence → recommendation. Capabilities de aprovação, cancelamento, re-run, compare; nunca afirmar que uma proposta foi treinada/deployada sem run terminal verificado.

## Tracing
OTel com `agent_run_id`, `model_id`, `tool_name`, `dataset_snapshot`, `latency_ms`, `input_tokens`, `output_tokens`, `cost_estimate`. Redact prompts, image bytes, secrets e PII. Export local por default.
