# 09 — Frontend: LAIbemage Studio

## Experiência central
Produto é workbench para exploração técnica e tomada de decisão: datasets, exploração visual, annotation, experiment/eval, agent traces, deployments. Não projetar navegação por tecnologias (`CLIP`, `PyTorch`) mas por trabalhos (`inspect`, `review`, `compare`, `ship`).

## Information architecture
- Workspace overview: projetos, jobs, dados, riscos, custos, models, alerts.
- Datasets: explorer/grid, table, splits, lineage, audit reports, snapshot diff.
- Annotate: classificação rápida, draw boxes, polygons/masks, adjudication queue, keyboard shortcuts.
- Search: text→image, image→image, filters, neighbors, coverage clusters.
- Models: registry, model cards, compatibility, licenses, checkpoints.
- Experiments: runs, charts, hyperparam compare, failure slices, drift.
- Arena: side-by-side predictions/overlays, prompts, latency/cost, A/B regression.
- Agent: conversational task specification + plan + tool tree + approvals + evidence.
- Jobs: status, progress, logs sanitized, cancel, resume/retry.
- Deploy: current model, canaries, release gates, rollback, monitoring (P2).
- Workspace settings: auth/roles, storage, provider credentials, budgets, retention.

## Design system
Tokens `color-bg`, `surface`, `text`, `border`, `focus`, semantic error/warning/success; typographic scale, spacing, density, motion, icon guidelines, responsive behavior, theme high-contrast. shadcn components are starting points, not unmodified accessibility guarantees. Storybook docs and interaction tests; screenshot regression for high impact views.

## Component boundaries
`apps/studio/features/{datasets,annotations,experiments,agents,models}`; `packages/ui` for primitives; feature-layer domain adapters; TanStack Query is server-state authority; transient drawing state local with command history (undo/redo). URL query is sharable filters/sorting/tabs; never put secrets or huge masks in URL. State machine for annotation editing/approval vs results.

## Performance requirements
- Gallery server-side pagination + virtualization; render only viewport images with progressive thumbnails; cache-by-digest; original loaded on demand.
- No base64 in list JSON; use signed media URLs with TTL; CORS/permissions enforced.
- Canvas handles zoom/pan and geometry transforms with normalized coordinate model; offscreen thumbnails; memory limits and URL revocation.
- Heavy embeddings plots/cluster computation in workers/backend, not main thread; graph sampling to avoid 100k DOM nodes.
- Time-to-interactive, INP, p75 LCP budgets configured after baseline and hardware target; validate on real datasets.
- Concurrency: `If-Match` and conflict dialog; never silently overwrite annotations.

## Annotation architecture
`ImageViewport` displays image + overlay layers; `AnnotationDocument` holds immutable base, editing draft, history; tool plugins implement pointers; `CoordinateTransform` converts canonical pixel coords ↔ display ↔ zoom; masks stored as artifact references and tiles; autosave drafts with explicit commit/approve. Text tasks avoid relying solely on canvas.

## Agent UI
Timeline of jobs, plan checkpoints, tool calls and evidence; human approval dialog shows exact tool, scope, data exposure, estimated cost and rollback. Provide cancel button; lack of response is not approval. Disabled controls must communicate reason. Render read-only resources, not executable markdown instructions as trusted UI.

## Accessibility checklist
Keyboard-only for dataset table, classification, review, dialogs and toolbar; canvas has alternative list-based geometry editor; focus visible; announcements for changes/async status; proper `aria-label`, description, row headers, table name; no color-only meaning; adjustable motion/reduced motion; captions for video; alt text for UI controls (not automatically generated training labels as accessibility certainty). Test axe + manual screen reader.

## Design acceptance examples
- Import 10k images: no browser tab crash; list remains responsive and paging stable.
- Annotation re-open: corrections persisted with consistent coordinate transforms on different screen sizes.
- Large-image scan: zoom/resize preserves normalized geometry and highlights active box accessibly.
- Compare two model runs: user can inspect every error slice and jump to source sample/run.
- Agent approval: cannot approve stale proposal (fingerprint mismatch).
