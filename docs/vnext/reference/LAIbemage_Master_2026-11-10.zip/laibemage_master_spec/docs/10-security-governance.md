# 10 — Segurança, privacidade, governança e licenciamento

## Threat model / trust boundaries
**Entradas não confiáveis:** mídia, EXIF, PDFs, URLs de importação, datasets, modelos/weights, OCR text, prompts, plugins, MCP tool input, artefatos gerados por agentes. **Ativos protegidos:** dados privados, credenciais cloud/API, modelos proprietários, dados anotados, traces, run reports, identidade e autorização, integridade de ML pipeline.

### Ameaças / controles
| Ameaça | Controle mínimo |
|---|---|
| Path traversal e symlinks | Canonicalização, allowlist por workspace, O_NOFOLLOW quando aplicável, storage handles em vez de paths arbitrários |
| Zip bomb / image bomb | caps bytes/pixels/pages/frames, process limits, safe decode, timeouts |
| SSRF em URL ingest | deny private/link-local/metadata IP, DNS rebinding defense, egress allowlists, redirects revalidated |
| RCE em decoder/pickle | sandbox container, packages patched, safetensors; tratar checkpoints como executáveis não confiáveis |
| Prompt injection via OCR/EXIF | dado isolado de instruções; tool auth independente; escopos restritos; redteam |
| Excessive agency | allowlisted tools, budgets, approvals e hard-stop; sem shell genérico |
| Cross-workspace leakage | authz no caso de uso, row filters, prefixes seguros, testes negative |
| Exfiltração por provider | cloud opt-in, classificação de dado, consentimento/config, masked/redacted media |
| Fuga de segredos nos logs | allowlist de atributos, redaction, retention; não gravar prompts raw por default |
| Poisoning dataset/label | provenance, approval, quarantine, dataset-quality scans e golden holdout |
| Supply chain | dep scan, SBOM, hashes, assinatura/attestation se possível, licença de pesos e datasets |
| DoS GPU/compute | quotas por usuário, deadline, memory/compute caps, queue fairness, cancellation |
| Prompt/tool result HTML injection | escapamento/sanitização, CSP, sem executar markdown HTML, tratar labels como texto |

## IAM e mode matrix
- Desktop: apenas loopback autenticado com token aleatório de sessão; não assumir localhost = trusted. CLI tem permissão local explícita ao workspace path. MCP stdio herda identity/capabilities do host somente se validados; não confiar em ambiente indiscriminadamente.
- Team: OIDC com MFA do IdP, RBAC e policy por workspace/dataset, tokens com audience/scopes/TTL, session rotation, server-side revocation. No plaintext service keys em DB; vault/OS keychain/secret manager.
- Remote MCP: valid token per request, CORS/origin validation, host validation, rate-limit, audit; ferramentas limitadas pelo scope.

## Data privacy / LGPD
Catalogar finalidade, base legal aplicável, período de retenção, país/transferências, consentimento quando necessário, solicitações de titulares e processo de exclusão. Alguns datasets têm pessoas, documentos, placas ou dados médicos; políticas devem impedir envio cloud sem autorização adequada. Registrar EXIF GPS, faces e OCR PII como dados potencialmente sensíveis. Não prometer conformidade LGPD automaticamente; exigir avaliação jurídica por uso/região.

## Security design gates
- Segurança de importação em revisão antes de habilitar import URL e plugins terceiros.
- Acesso a assets é mediado pelo backend com token curto e bound ao workspace; evitar URL pública persistente.
- Logs de auditoria append-only com actor, permission, resource, action, outcome, trace, timestamp e user-visible decision.
- Migration de schema tem rollback/backup e validação de permissões.
- Se multi-tenant: RLS complementa autorização de aplicação, nunca substitui testes de authz.

## Dataset/model licensing
Cada dataset registra `source_url`, licença SPDX quando possível, termos, finalidade permitida (research/commercial), atribuição e retenção. Cada weight registra licença independente do código. Não supor que AGPL de framework ou uso comercial de dataset permite distribuição/serviço sem obrigações. Gate antes de export/publish model. Licença `research only` bloqueia deployment comercial por default.

## Model cards e governance
Documentar tarefas/usuários pretendidos, limites, dataset composition, classes sensíveis, riscos de false negative/positive, licença, avaliação por slice, calibração, hardware e uso não pretendido. Dataset cards documentam fonte e qualidade; decision log registra motivo de promoção/negação.

## Segurança de agentes e modelos
- LLM output sempre validado Zod/Pydantic antes de ação.
- Não confiar em autodeclared confidence.
- Models downloaded only from allowlisted registries; if pickle is required, execute isolated and document risk.
- User-uploaded plugins disabled em ambiente shared até haver sandbox e assinatura.
- Testes OWASP GenAI/LLM: instruções dentro de imagem/documento, confusão de escopo, argumento malicioso, tool output poisoning, custo em loop.

## Referências
https://genai.owasp.org/glossary/prompt-injection/ ; https://airc.nist.gov/airmf-resources/playbook/measure/ ; https://modelcontextprotocol.io/specification/2026-07-28
