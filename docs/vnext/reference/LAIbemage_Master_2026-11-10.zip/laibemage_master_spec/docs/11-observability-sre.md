# 11 — Observabilidade, operação e SRE

## Telemetry architecture
OpenTelemetry instrumentation (Fastify, workers, Python) → Collector local/team → Tempo/Jaeger optional trace store; Prometheus metrics → Grafana; structured JSON logs → stdout/file/Loki optional. Nunca fazer da instalação de Grafana condição para usar CLI local. Em desktop use `laib diagnostics` + local JSON/SQLite trace view.

## Trace model
Parent/child `http.request → use_case → transaction → job.enqueue → job.execute → python.worker → model.infer/train → artifact.save → evaluation.compute`. `trace_id` propagado como atributo/context; async job usa span links quando execution crosses process/time boundaries. Guardar `job_id`, `workspace_id` hash/safe reference, `dataset_snapshot_id`, `model_version_id`, `experiment_run_id` e `artifact_ref`.

## Métricas mínimas
| Métrica | Tipo | Uso |
|---|---|---|
| `laib_jobs_total{type,status}` | counter | taxa falha por tipo |
| `laib_job_duration_seconds{type}` | histogram | p50/p95 runtime |
| `laib_queue_wait_seconds{queue}` | histogram | capacidade |
| `laib_image_ingest_total{result}` | counter | ingestão |
| `laib_inference_duration_seconds{model_family,device}` | histogram | performance |
| `laib_inference_errors_total{reason}` | counter | erros |
| `laib_inference_cost_usd{provider}` | counter | custo estimado |
| `laib_annotations_reviewed_total{source}` | counter | esforço humano |
| `laib_agent_tool_calls_total{tool,outcome}` | counter | ferramentas/segurança |
| `laib_agent_budget_exceeded_total` | counter | abortos |
| `laib_model_drift_score{deployment,feature_group}` | gauge | detectar shift |
| `laib_cas_bytes_total{tier}` | gauge | uso storage |

Evite label cardinality de `sample_id`/`user_id` em métricas Prometheus. IDs pertencem a trace/log, com políticas de retenção e redaction.

## SLOs propostos (metas iniciais, não promessas)
- Shared API availability: 99.9% mensal (quando houver SLA comercial e HA); local offline não usa availability SLA.
- P95 GET dataset metadata < 250ms para payload paginado <=100 itens em staging de referência.
- 99% dos jobs aceitos apresentam estado consultável em < 5s; tempo total depende do tipo de treino e hardware.
- Crash recover: nenhum snapshot aprovado ou asset CAS perde integridade; fila recupera após restart.
- Zero auto-promotion sem gate e autorização; zero cross-workspace leaks nos testes.
- Validação visual deve declarar recall mínimo por classe crítica com amostra suficiente e intervalo de confiança; não transformar 95% em meta universal sem risco.

## Dashboard operacional
Queue depth, queue age, job failures, GPU utilization, model latency, ingest failure/codec, number of snapshots, storage usage, cost per accepted sample, eval drift, alert false positive/negative. Agent trace mostra ferramentas, argumentos sanitizados, budgets, aprovação, evidência.

## Alertas
- Urgente: authz violation suspected, data corruption, asset digest mismatch, unexpected model promotion, repeated job failures, cost threshold exceeded.
- Warning: queue age high, drift persistent, low coverage, disabled provider, unexpected annotation disagreement, expiring credentials.
- Definir owner, threshold, suppression, link runbook e severidade; evitar alert fatigue.

## Runbooks
1. **DB unavailable:** healthcheck, stop mutations, do not discard jobs, repair/restart; restore on sandbox, check WAL/backup.
2. **CAS digest mismatch:** quarantine object, revoke public access, identify lineage, regenerate derived artifacts, alert integrity owner.
3. **GPU OOM:** stop job, checkpoint if possible, reduce batch / switch CPU, classify retryable vs config error; record resource usage.
4. **Inference regression:** freeze rollout, compare golden runs, inspect shifts/config/ontology changes, rollback alias to previous verified model.
5. **Agent loop:** enforce hard tool/time/cost stop, preserve trace, revoke pending approval, review policy.
6. **Provider outage:** circuit breaker, local fallback only if meets quality policy, otherwise abstain/review.

## Backup/restore
Postgres PITR or pg_dump according to profile; CAS mirrored/snapshotted separately; MLflow artifact store and lock/manifest; secrets stored independently. Perform restore drill quarterly in team profile; record RPO/RTO objectives after measuring actual environment. Database backup without artifacts is not a full recovery.
