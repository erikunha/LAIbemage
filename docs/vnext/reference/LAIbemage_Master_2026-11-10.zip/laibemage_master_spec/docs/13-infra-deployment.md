# 13 — Infraestrutura, ambientes, deploy e continuidade

## Perfis de implantação
### Local developer (P0)
- Mac/Linux; Node Active LTS + pnpm, Python 3.12 + uv; Docker Compose para PostgreSQL com pgvector opcional.
- `LAIB_MODE=local`, API e Studio bind 127.0.0.1, random session auth, filesystem CAS, modelos CPU/MPS/opt-in local Ollama/VLM adapter, MLflow local directory.
- Zero cloud dependency e zero telemetria externa por default. GPU não exigida para baseline linear-probe; não prometer que modelos grandes cabem em Mac M2 sem medir RAM.
- Na primeira execução, wizard verifica acessibilidade do Postgres, espaço livre, permissões e device; comando `laib doctor` reporta warnings.

### Team/self-hosted (P1/P2)
- Compose hardened ou VM: PG, object storage, Fastify service, workers, Python inference/training images, OIDC, reverse proxy TLS, backup, isolated GPU optional.
- OIDC scopes, quotas por usuário, audit, SSO, storage encryption, cost caps. Deployment plane com staging separado, migration strategy.

### Enterprise/cloud (P3)
- IaC Terraform/OpenTofu, Kubernetes + workload identity, managed PostgreSQL/object storage, GPU job pools, autoscaling baseado na queue, secret manager, S3 policy e network policies, canary/blue-green.
- Só adotar se necessidade de HA, multi-tenant, alta throughput ou política corporativa justificar. Sem promessa de cloud-agnostic perfeita sem testes cruzados.

## Runtime topology
- App API: stateless process, requests curtas.
- Jobs: PG queue em transações com estado e outbox, concurrency limitada por tipo e recurso.
- Python worker: subprocess isolado no desktop com limite CPU/RAM/tempo; no shared, processo/container separado com controle de GPU, watchdog e checkpoint.
- MLflow: local store em M0; registry remoto requer backend DB configurado (não assumir que diretório de runs oferece todas as funções de registry).
- CAS: staging/hash/atomic rename + GC; adaptador S3 implementa multipart e checksums; derived assets podem ser regenerados se originais intactos.

## Dev commands desejados
```bash
pnpm install --frozen-lockfile
uv sync --locked
pnpm env:up        # compose PG + optional services (a implementar)
pnpm dev           # studio + api + worker (a implementar)
pnpm test
pnpm check
uv run pytest -q
laib doctor
```
Comandos `pnpm env:up`, `pnpm dev`, `laib doctor` são design targets, não existentes. `examples/docker-compose.reference.yml` é exemplo de PostgreSQL *somente*, não stack completa.

## Deployment pipeline
Build → unit/contract/ML smoke → security scan → image build (SBOM, provenance) → staging migration → deploy → smoke/readiness → shadow eval (se modelo) → canary gated → full rollout → monitor → rollback-ready. Provider/weights/ML pipelines versionados e artefatos verificados por SHA.

## Release/rollback
- API semver, schema migrations expand/contract, clientes compatíveis N-1 por janela definida.
- DB migrations forward-safe; backward compatibility test antes de deploy. Snapshot/backup antes de migrations destrutivas.
- Modelo versionado: alterar `champion` alias depois de approval e predeploy eval; rollback aponta para última versão validada.
- CLI/sdk semver com deprecation policy, changelog e teste de compatibilidade de comandos preexistentes.
- Model artifact restore + code/image revision must match exact input/preprocess contract.

## Sizing e custos (antes de estimar cifras)
Instrumentar ingest MB/s, média assets, # embeddings e dimensões, volume duplicado, GPU hours, billed tokens, cache, retention, queue wait, query p95; em cima disso construir cenários 10k/100k/1M assets. Sem benchmark, custos absolutos são placeholders.

## Operação de filas
Queues separadas por workload (`ingest`, `embedding`, `training`, `evaluation`, `agent`, `export`); limites globais e por tenant; prioridade fairness; deadlines e heartbeat. Dead-letter requer operador; retentativas apenas em falhas classificadas transitórias; treino com checkpoint recomeça conscientemente e registra lineage.

## Constraints e observações
- Mac MPS: verificar operação/precision suportada; fallback para CPU deve aparecer em métricas e relatório.
- Arquivos originais podem ser grandes e conter dados sensíveis; não copiar para SaaS por default.
- Exports e report generation podem ser assíncronos, com TTL de download e limpeza.
- Para vídeo/Physical AI, armazenamento e compute multiplicam; não antecipar cluster sem benchmark.
