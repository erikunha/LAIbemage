# 14 — Roadmap, dependências, backlog e milestones

## Estratégia de entrega
Cada fase é um vertical slice verificável, não um sprint de instalação de bibliotecas. Uma sprint de 2 semanas é uma cadência proposta, não compromisso de prazo. O plano completo tem capacidade superior à de um desenvolvedor em poucas semanas: priorizar M0 e M1 para portfólio e aprendizado, expandir mediante medição.

## M0 — Foundation & parity (2–4 semanas indicativas)
**Entrega:** monorepo inicial, contratos, audit do legado, Postgres local, asset store CAS, teste real de classificação e snapshot reproduzível.
- Consolidar repositório e marcar baseline/tag; não descartar testes existentes.
- Executar CI atual e documentar falhas/dependencies e custos.
- Corrigir hash de configuração: incluir category descriptions, model, prompt, preprocess e versões.
- Separar AnalysisResult/ProcessedResult com provenance de Prediction/Annotation.
- Port de CLI legado com testes golden de comportamento, sem reescrever tudo.
- PostgreSQL schema migrations, StoragePort, asset metadata, dataset snapshot.
- Teste de ponta a ponta import→snapshot→eval offline.
**Gate:** `docs/16-definition-of-done.md` M0; primeiro dataset público licenciado e checksum íntegro.

## M1 — Visual workbench & ML baseline (4–8 semanas indicativas)
**Entrega:** Studio visual, dataset explorer, classificação/human review, visual embeddings, linear probe, VLM, MLflow e report real.
- Dataset audit (dup/leakage/imbalance).
- Versioned annotation UI classification + blind review + optimistic lock.
- SigLIP/CLIP embeddings, pgvector, nearest neighbor gallery.
- Python ML adapter, sk-learn linear probe, VLM adapter e evaluation service.
- Experiments side-by-side e per-sample failure slices.
- Baseline científico público com datasheet, metric CI e cost table.
**Gate:** reproduzir 2 modelos em snapshot lacrado e medir quality/cost/latency com hardware declarado.

## M2 — Data Flywheel & Optimization (6–10 semanas indicativas)
**Entrega:** training PyTorch, active learning, model registry e router quality-cost.
- Augmentation + transfer learning; MLflow logging.
- Active learning: uncertainty, diversity, random control, review budget; no test leakage.
- Calibrated threshold / abstain; cost-per-accepted-decision.
- Reproducible candidate vs baseline with statistical uncertainty.
- Model promotion proposal gated by policy and approval.
**Gate:** evidência de ganho no holdout vs random selection (ou conclusão negativa bem documentada).

## M3 — Agents, MCP & platform (4–8 semanas indicativas)
**Entrega:** agent investigator read-only, experiment proposals, job submission via explicit approval, MCP, observabilidade.
- LangGraph trace/checkpoint, evidence references, typed tools.
- CLI+Studio+MCP parity contract tests.
- MCP TS v2 stdio local, remote HTTP P2, auth.
- Eval agent vs workflow baseline com redteam injection.
- Budget/time/iterations hard limits.
**Gate:** zero unauthorized effect em adversarial suite; promoção de modelo permanece human-gated.

## M4 — Team / production (após evidência de usuários)
OIDC, permissions per dataset, object store remote, CI/CD gated, model drift, canary/rollback, restore drills, usage accounting, latency SLO. Testes com usuários não especializados e perfis de suporte.

## M5 — Frontier R&D (projetos separados por domínio)
Video events, tracking, SAM/text-conditioned segmentation, edge inference, synthetic data/Physical AI, geospatial/sensors, teacher-student distillation. Cada experimento precisa registrar ROI, dados, hardware e licença.

## Roadmap dependency graph
```mermaid
flowchart LR
 A[CAS + dataset/ontology contracts] --> B[Annotated snapshots]
 B --> C[ML baseline + evaluation]
 C --> D[Studio compare and review]
 C --> E[Train + active learning]
 E --> F[Model registry + optimization]
 F --> G[Agent proposal + MCP]
 D --> G
 F --> H[Deploy + monitoring]
```

## Backlog priorizado
| Epic | P | Must-have acceptance |
|---|---|---|
| Versioned dataset snapshots | P0 | hash replayable, no mutation |
| Real-world benchmark | P0 | real labeled data, split/leakage audit |
| Model score semantics | P0 | separate raw vs calibrated |
| End-to-end job engine | P0 | resumable, idempotent, cancel |
| Studio dataset+review | P0 | keyboard/a11y, revision history |
| ML linear probe vs VLM | P0 | reproducible same task |
| Experiment comparison | P0 | per-class/regressions/CI |
| Embedding search | P1 | indexed by model/version |
| PyTorch transfer learning | P1 | repeatable run/checkpoint |
| Active learning | P1 | random baseline comparator |
| Cost-aware routing | P1 | quality constraint regression gate |
| MCP + agent investigation | P1 | scopes/evidence/approval |
| Model deployment | P2 | release gate, rollback, monitor |
| Video/segment/Physical AI | P2 | real demand and compute budget |

## Indicadores de saída (não target fabricated)
Cada milestone entrega: demo gravável, changelog, ADR, custos do run, dataset card, eval report, testes, risco e aprendizado. Acompanhar tempo de desenvolvimento, custo operacional, qualidade, número de falhas e dificuldade do usuário concluir o workflow.
