# 15 — Fontes e bibliografia técnica

**Regra:** referências abaixo sustentam escolhas técnicas e padrões; não provam TAM, PMF, salários, custos atuais ou qualidade do LAIbemage. A cada implementação revisar últimas versões e licenças.

## Protocolo, plataforma e frontend
- MCP spec estável (2026-07-28): https://modelcontextprotocol.io/specification/2026-07-28
- MCP stdio/transport: https://modelcontextprotocol.io/specification/2026-07-28/basic/transports/stdio
- MCP tools/security: https://modelcontextprotocol.io/specification/2026-07-28/server/tools
- MCP TypeScript SDK v2: https://ts.sdk.modelcontextprotocol.io/v2/
- Fastify reference: https://fastify.dev/docs/latest/
- Next.js App Router: https://nextjs.org/docs/app
- uv workspaces: https://docs.astral.sh/uv/concepts/projects/workspaces/
- OpenTelemetry: https://opentelemetry.io/docs/

## Data, vector, MLOps
- LanceDB: https://docs.lancedb.com/
- DVC data/pipelines: https://doc.dvc.org/user-guide/pipelines/defining-pipelines
- MLflow Tracking: https://www.mlflow.org/docs/latest/tracking/
- MLflow Model Registry: https://www.mlflow.org/docs/latest/model-registry/
- PostgreSQL: https://www.postgresql.org/docs/current/
- pgvector: https://github.com/pgvector/pgvector
- DuckDB: https://duckdb.org/docs/stable/

## ML / CV / inferência
- PyTorch MPS: https://docs.pytorch.org/docs/stable/notes/mps.html
- Transfer learning tutorial: https://docs.pytorch.org/tutorials/beginner/transfer_learning_tutorial.html
- ONNX Runtime EPs: https://onnxruntime.ai/docs/execution-providers/
- CLIP: https://proceedings.mlr.press/v139/radford21a.html
- SigLIP 2: https://arxiv.org/abs/2502.14786
- DINOv3: https://arxiv.org/abs/2508.10104
- SAM 3: https://arxiv.org/abs/2511.16719
- Ultralytics classification dataset format: https://docs.ultralytics.com/datasets/classify
- Ultralytics object detection dataset format: https://docs.ultralytics.com/datasets/detect
- FiftyOne: https://docs.voxel51.com/
- CVAT: https://docs.cvat.ai/
- Label Studio: https://labelstud.io/guide/
- Roboflow: https://docs.roboflow.com/

## Trust, risk, eval
- NIST AI RMF Measure: https://airc.nist.gov/airmf-resources/playbook/measure/
- OWASP prompt injection: https://genai.owasp.org/glossary/prompt-injection/
- OWASP LLM application threats: https://owasp.org/projects/top-10-for-large-language-model-applications
- LangGraph docs: https://docs.langchain.com/oss/python/langgraph/overview
- VLM confidence/uncertainty papers: consultar primárias e replicar experimentos, não tratar score gerado como probabilidade calibrada.

## Project baselines
- LAIbemage: https://github.com/erikunha/LAIbemage
- LedgerLens: https://github.com/erikunha/ledgerlens

## Checagens pendentes
1. Confirmar combinações de versions Node/TS/Next/Fastify e Python/PyTorch/Transformers com lockfile e CI.
2. Verificar licença exata de cada model checkpoint (não apenas framework) e dataset conforme uso comercial.
3. Medir memória e throughput Mac M2 com modelos escolhidos; modelos 3D/segmenters pesados podem exigir GPU remota opcional.
4. Executar benchmark com dataset real e documentar erros; números em exemplos são ilustrativos.
5. Revisar política de dados (LGPD/PII, retenção, export) para usuários reais e jurisdição.
