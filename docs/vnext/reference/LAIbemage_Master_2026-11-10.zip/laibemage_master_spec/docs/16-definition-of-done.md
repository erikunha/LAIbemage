# 16 — Definition of Done e quality gates

## Gate de cada PR
- [ ] Mudança mapeada a issue/ADR e aceitação testável.
- [ ] Sem regressão em CLI/API/SDK; fixtures atualizadas quando contrato muda.
- [ ] Unit e integration tests passam em CI declarada; testes reais não são substituídos por afirmações de agentes.
- [ ] Tipagem, lint, formatação, SCA, secrets e licenças checados.
- [ ] Dados e modelos usados têm hashes, fontes, licenças e split documentados.
- [ ] Logs/traces/metrics úteis; sem segredos ou PII sensível por default.
- [ ] UI acessível via teclado, erro/loading/empty/retry estados e sem perda de dados.
- [ ] Impacto de performance, custo e storage medido ou explicitamente não aplicável.
- [ ] ADR/docs atualizados; rollback/feature flag quando necessário.

## Gate M0: sistema local executável
- [ ] Ambiente Mac/Linux inicializa com comandos documentados, sem chaves cloud.
- [ ] Imagem real importada com SHA-256 verificado e preview seguro.
- [ ] Dataset snapshot imutável e audit de leakage.
- [ ] Evals rodam com baseline, reportam metrics, run_id, source, hardware, artifacts.
- [ ] CLI preexistente mantém comportamento validado em golden tests ou breaking change explícito.

## Gate M1: ML real + Studio
- [ ] Classifier tradicional e VLM avaliados na mesma tarefa e snapshot.
- [ ] Dataset Explorer lazy/virtualized e Annotation Editor com undo/revision.
- [ ] Score bruto, calibrated e ground truth não confundidos.
- [ ] Per-class confusion/errors e comparador por sample disponíveis.
- [ ] Testes E2E confirmam persistência, auth e redaction.

## Gate M2: learning flywheel
- [ ] Experimento PyTorch reproduzível com cfg/seed/commit/weights.
- [ ] Correções humanas alimentam somente snapshots novos e não contaminam holdout.
- [ ] Active learning comparado com random selection.
- [ ] Qualidade-custo reportada com incerteza, tradeoff explícito e baseline.

## Gate M3: agentes e MCP
- [ ] Versão MCP 2026-07-28 funciona com pelo menos um cliente real e mocks.
- [ ] Tool-scopes, approval, budget e tenant restrictions têm negative tests.
- [ ] Agent evaluation vs baseline documentada com falhas.
- [ ] Todos os claims materiais citam EvidenceRefs; no evidence => hypothesis/abstain.
- [ ] Qualquer job disparado pelo agente deixa audit e é cancelável quando viável.

## Gate M4: produção e colaboração
- [ ] Auth OIDC, backups/restore drill, secret rotation e audit review.
- [ ] Release gate bloqueia modelos regressivos e mantém rollback pronto.
- [ ] SLOs medidos com incident runbooks e on-call ownership.
- [ ] Regime de licenças/termos/LGPD revisado para produto/cliente.
