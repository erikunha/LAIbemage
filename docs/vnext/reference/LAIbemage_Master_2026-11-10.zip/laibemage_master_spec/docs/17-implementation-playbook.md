# 17 — Engineering playbook e implementação assistida por agentes

## Como começar sem destruir o legado
1. Tirar tag do estado atual do LAIbemage, clonar branch de migração e registrar `baseline-audit.md` com resultados de testes e comandos executados.
2. Corrigir incompatibilidades antes de movimentar arquivos; Git history preservado, DRY-run migração de CLI e golden outputs.
3. Criar `packages/contracts` e domínio `Asset/Sample/Annotation/Prediction` antes de frontend e MCP.
4. Extrair a pipeline atual em `packages/legacy-cli` ou `packages/image-pipeline` por *strangler pattern*; manter comandos antigos enquanto os novos use cases surgem.
5. Criar caso real vertical, end-to-end; somente depois expandir especialidades.

## Política de Git
Trunk-based com feature branches pequenas; Conventional Commits, PR template com motivação, dados/testes/métricas, risco/rollback, impacto em contrato. CODEOWNERS por contexto; branch protection, status checks, secret scanning. Renovate/Dependabot PRs com CI; evita merge cego.

## Template de RFC
- Contexto e problema real.
- Objetivo, não objetivos, usuários e orçamento.
- Alternativas com trade-offs e evidência.
- Domain contracts e plano de migração.
- Segurança, dados, performance, observabilidade.
- Métricas de sucesso, baseline, avaliação e failure modes.
- Deployment/rollback e ownership.
- Open questions com dono/prazo.

## Prompt de implementação para assistente de código
```
Read README + relevant docs and existing code before editing.
Implement ONLY the scope of issue X and preserve current CLI behavior.
Use versioned contracts and existing application use cases.
Do not add services, providers or dependencies without an ADR.
Add negative tests for auth, idempotency and missing/corrupt data.
For ML claims, run the evaluation and record dataset/split/seed/hardware.
Run static checks/tests and report exact commands, outcomes and known gaps.
Do not push to production or change remote infrastructure.
```

## Revisões recomendadas
- Software architecture reviewer: boundaries, correctness, use cases, recoverability.
- ML reviewer: leakage, metrics, CI, calibration, samples, confusion, reproducibility.
- Security reviewer: untrusted files, auth, tool/agent permissions, secrets.
- UX reviewer: annotation accuracy, keyboard/a11y, failure states and feedback.
Exigir evidências determinísticas; múltiplos agentes concordando não substitui testes/benchmarks.

## Cadência experimental
Research spike → baseline → hypothesis → constrained experiment → evidence-based decision → ADR → implementation. Relatórios com resultados negativos são úteis. Registrar custo e tempo de cada experimento, não só melhores números.

## Documentação obrigatória do repositório
`README.md`, `CONTRIBUTING.md`, `CODE_OF_CONDUCT.md` (se colaboração pública), `SECURITY.md`, `LICENSE`, `NOTICE`, `ARCHITECTURE.md`, `/docs/adr`, `/docs/rfcs`, `/docs/runbooks`, `/docs/ml/model-cards`, `/docs/data/dataset-cards`, `openapi.yaml`, `mcp-tools.md`, CLI help, SDK reference, `CHANGELOG.md`, `AGENTS.md`, `CLAUDE.md` se usados, privacy/retention policy, `deploy.md`, `migration.md`, `eval methodology.md`, issue/PR templates.

## Ownership de decisões
Domain schema changes: architecture+data owner. New model: ML evaluator+license reviewer. Agent tool with side effects: security+API owner. Deployment with risk: operator/product owner. Em projeto individual, documentar papéis como checklists, não simular aprovações externas que não ocorreram.
