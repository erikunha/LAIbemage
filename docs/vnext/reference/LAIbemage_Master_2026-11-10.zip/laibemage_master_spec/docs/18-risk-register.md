# 18 — Registro de riscos e premissas

| ID | Risco | P/I | Mitigação | Evidência para remover risco |
|---|---|---|---|---|
| R01 | Scope creep, app inacabado | Alta/Alta | vertical slices e gate | demo completo e avaliável |
| R02 | Benchmarks sintéticos irrelevantes | Alta/Alta | gold dataset real e holdout | métricas com classes reais |
| R03 | Leakage entre split | Média/Alta | group split + near-dup scan | report de leakage |
| R04 | LLM confidence não calibrada | Alta/Alta | calibração/abstain; eval | reliability plot e CI |
| R05 | Python/TS contracts drift | Média/Alta | schemas e cross-lang tests | CI contrato |
| R06 | GPU insuficiente no Mac | Alta/Média | linear probe / MPS / CPU fallback | benchmark hardware real |
| R07 | Violação de licenças | Média/Alta | registry e gate | licença por asset/model |
| R08 | Agentes executam ações impróprias | Média/Crítica | scopes, approval, budget | adversarial eval |
| R09 | PII em imagem enviada para cloud | Média/Crítica | local default, privacy gate | audit de egress |
| R10 | Tenant data leakage | Média/Crítica | policy boundaries e tests | negative auth tests |
| R11 | Índice vetorial inconsistente | Média/Média | embed model/version fingerprint | reindex/compat tests |
| R12 | Jobs duplicados ou perdidos | Média/Alta | durable queue/outbox/idempotency | chaos + restart tests |
| R13 | Model regression após deploy | Média/Alta | gate+canary+rollback | shadow eval/rollback drill |
| R14 | Tooling pesa mais que valor | Alta/Alta | no K8s/graph DB/Temporal em M0 | dados de bottleneck |
| R15 | No budget/PMF | Alta/Alta | buyer interviews e ROI | orçamento real de cliente |

## Hipóteses falsificáveis
- H1: encoder local + classificador especializado compete com VLM em subconjunto de inspeção. Falsificar com holdout blind e CI.
- H2: active learning reduz número de anotações para o mesmo recall. Falsificar vs random acquisition sob mesmo budget.
- H3: um agente reduz tempo de investigação sem perder rigor. Falsificar contra workflow determinístico e erro humano.
- H4: custo operacional de um modelo maior pode ser reduzido com routing sem prejudicar classes críticas. Falsificar sob paired eval e custo real.
- H5: equipes pagariam por essa integração. Falsificar com discovery, pilotos, willingness to pay e problemas atuais.

## Riscos residuais
Nenhum modelo de visão está livre de distribuição shift. Explicações de VLMs podem soar corretas mesmo sem evidência visual. Custos de erro reais são difíceis de estimar; sempre sinalizar estimativa vs despesa observada. Treinar no Mac M2 tem limitações por memória e ops disponíveis. Códigos de exemplo ainda não são implementation-ready sem CI e testes de deploy.
