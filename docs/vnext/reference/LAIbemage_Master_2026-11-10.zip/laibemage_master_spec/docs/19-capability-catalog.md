# 19 — Capability catalog e matriz de implementação

Esta matriz descreve **escopo do produto futuro**, não funcionalidades já implementadas. Use como backlog de descoberta e requisitos em RFCs. Prioridade P0 primeiro vertical slice; P1 depois do benchmark; P2 somente quando necessário. Preferir integrar componentes existentes a construir tudo do zero.

## 1. Workspace e governance
| Capability | P | Contrato/critério |
|---|---|---|
| Workspace/role scopes | 0 | acesso por workspace e dataset, least privilege |
| Dataset/project RBAC | 1 | test authz negative por papel |
| License registry | 0 | asset/model data license e commercial gate |
| Audit trail | 0 | actor, resource, action, outcome, trace |
| Retention/deletion lifecycle | 1 | CAS GC com lineage/refcounts e legal hold |
| Consent/PII policies | 1 | private data blocks provider egress |
| SSO/OIDC/SAML | 2 | conectores gerenciados e testes de sessão |
| Multi-tenancy hard isolation | 2 | isolated storage/DB policies + audit |

## 2. Asset catalog
| Capability | P | Contrato/critério |
|---|---|---|
| Ingest directory, upload | 0 | sha256, mime, dedup, metadata |
| Recursive watch/import | 1 | idempotent incremental scan |
| Import URL/cloud | 1 | SSRF defense, credentials scopes |
| EXIF + preview | 0 | orientation, GPS configurable, safe decoder |
| Video decode/frame graph | 2 | timestamp accuracy and frame lineage |
| Multi-camera synchronization | 2 | calibration model and time uncertainty |
| Thermal/depth/LiDAR ingest | 2 | metadata schema and unit support |
| Image provenance/transform | 0 | raw immutable, renditions versioned |

## 3. Dataset engineering
| Capability | P | Contrato/critério |
|---|---|---|
| Dataset snapshot/frozen manifest | 0 | deterministic sha and reproducible contents |
| Ontology with versions | 0 | rename/remap explicit, no hidden retroactive changes |
| Grouped split & leakage detection | 0 | same capture groups don't cross partitions |
| Class distribution and imbalance | 0 | sample/class/group histograms |
| Duplicates and image quality audit | 0 | exact vs near-duplicate separate |
| Outlier and anomaly review | 1 | suggestions with model/source and evidence |
| Dataset diff / branch | 1 | immutable patches, lineage |
| Annotator agreement and adjudication | 1 | pairwise agreement, gold gate |
| Synthetic data provenance | 2 | simulator/model/seed and real-only holdout |
| Multi-label/relations ontology | 1 | compatibility with task-specific exports |

## 4. Annotation engine
| Capability | P | Contrato/critério |
|---|---|---|
| Whole-image classification | 0 | keyboard-first, batch review |
| Multi-label + hierarchical labels | 1 | ontology constraints |
| Bounding/rotated boxes | 1 | coordinate system precise |
| Polygons and masks | 1 | raster/geometry bridges |
| Keypoints / skeletons | 2 | per-task schema |
| OCR polygons and reading order | 1 | text provenance by region |
| Video timeline, tracks | 2 | stable track ID and frame mapping |
| Pre-label from model | 1 | suggested != approved |
| Blind QA / inter-annotator conflict | 1 | adjudicated ground truth |
| Annotation export formats | 1 | COCO/YOLO/CVAT/Label Studio mapped correctly |

## 5. Models and training
| Capability | P | Contrato/critério |
|---|---|---|
| Baseline scikit-learn | 0 | train/val/test separation and artifacts |
| Vision encoder embeddings | 0 | model/preprocess digest |
| VLM adapter | 0 | prompt+model cost, abstain, schema |
| PyTorch transfer learning | 1 | checkpoints, seeds, data cards |
| Classifier calibration | 1 | ECE/Brier/reliability plot |
| Detection/segmentation | 1 | per-task metrics and geometry output |
| Anomaly detection | 1 | AUROC/AUPRC caveats and region metrics |
| HPO with budget | 1 | Optuna trials/durable run state |
| Teacher-student pseudo-label | 1 | human verification and holdout |
| Model registry+cards | 1 | immutable version and gated promotion |
| Quantization, ONNX, CoreML | 2 | eval parity vs baseline and hardware support |
| GPU distributed training | 2 | cluster costs, checkpoint/reproducibility |

## 6. Search, reasoning and analytics
| Capability | P | Contrato/critério |
|---|---|---|
| Metadata + fulltext search | 0 | safe indexed filters |
| Text-image and image-image search | 1 | index fingerprints, retrieval eval |
| Visual nearest-neighbor explorer | 1 | human inspection of neighbors |
| Cluster/outlier plots | 1 | dimension reduction + sample metadata |
| Vision QA with evidence | 1 | region/frame references |
| Visual knowledge graph | 2 | typed relations with provenance |
| Video event retrieval | 2 | temporal IoU and timestamp accuracy |
| Cross-document OCR reasoning | 2 | field-level grounding/eval |

## 7. Experiment & evaluation
| Capability | P | Contrato/critério |
|---|---|---|
| Per-class metric + confusion | 0 | true holdout and denominators |
| Latency/cost/hardware benchmark | 0 | p50/p95, runtime, cost kind |
| Paired experiment compare | 0 | sample-level deltas and IC |
| Failure slice explorer | 0 | jump to sample/model predictions |
| Robustness/OOD experiments | 1 | separate slice metrics and dataset cards |
| Active learning vs random | 1 | budget-controlled ablation |
| Quality-cost Pareto analysis | 1 | constraints explicit |
| Release gating / model promotion | 1 | human approval and policy evidence |
| Model/drift monitoring | 2 | alert thresholds, sampling, rollback |

## 8. Platform / agent / operations
| Capability | P | Contrato/critério |
|---|---|---|
| CLI/SDK compatibility | 0 | golden contract tests |
| Studio datasets & review | 0 | E2E accessibility and optimistic lock |
| Fastify OpenAPI | 0 | generated typed clients, strict validation |
| Durable jobs + cancellation | 0 | idempotent and restart-tested |
| OTel structured instrumentation | 0 | redaction and correlation |
| MCP local stdio | 1 | tool validation/scopes and real client |
| LangGraph investigation agent | 1 | evidence + approval + evaluation |
| Agent tool budgets | 1 | strict time/cost/calls limits |
| Remote MCP + OIDC | 2 | authenticated stateless per-request |
| Deployment/canary/rollback | 2 | actual SLO and recovery tests |
| Enterprise billing | 2 | only with actual paid customer needs |

## Triggers de escala
- >100k samples with benchmarked slow vector queries → evaluate LanceDB/HNSW.
- Workflow spans days with compensation/approvals → evaluate Temporal.
- 3+ ML worker pools with GPU contention → dedicated resource scheduler.
- Multi-tenant customers and external API → OIDC, per-tenant data isolation and DR drills.
- Repeatedly failing human review → invest in annotator workflow before more model types.

## Critério de produto robusto
Uma capability conta como entregue somente quando tem testable user flow, contract, observability, user-visible failure behavior, security policy, metrics e docs. Não contar PoC isolada como lançamento de feature.
