# 20 — Sequência de implementação em tickets reviewáveis

Abaixo está um backlog inicial, organizado para dar progresso incremental com dependências claras. Cada ticket deve se tornar issue com responsável, escopo e screenshots/test evidence.

## Fundação (T01–T12)
| Ticket | Entrega | Critério mínimo |
|---|---|---|
| T01 | Audit baseline do LAIbemage | testes atuais executados e diferenças documentadas |
| T02 | Tag + feature branch de migração | rollback de branch + referências preservadas |
| T03 | Contratos JSON Schema / OpenAPI | schemata validados, generation CI |
| T04 | Modularização core/application | nenhuma lógica de domínio em CLI ou controller |
| T05 | Dev environment PG + uv/pnpm | commands documented and env validation |
| T06 | DB migrations tables asset/dataset | create/read/integrity tests |
| T07 | CAS storage file adapter | SHA hash validation, atomic-write tests |
| T08 | Ingest workflow | import 100 assets reais sem perda; errors por arquivo |
| T09 | Dataset snapshot/manifest | immutable + digest re-run |
| T10 | Annotation distinction | human/model separate, revisions stored |
| T11 | Leakage scan + group split | near duplicates/groups don't cross partitions |
| T12 | Basic CLI compatibility | old commands golden-test e deprecation decision |

## Primeiro vertical slice (T13–T25)
| Ticket | Entrega | Critério mínimo |
|---|---|---|
| T13 | Selecionar/publicar dataset card | licença e split documentados |
| T14 | ML worker contract + launcher | log structured, timeout, cancel, budget |
| T15 | Embedding feature extraction | deterministic metadata + model hash |
| T16 | scikit-learn linear probe | train/eval CLI runs with seed |
| T17 | VLM adapter | schema valid, cost tracing, abstain |
| T18 | Eval service | per-class F1/confusion, IC, failures |
| T19 | MLflow Tracking integration | run links, code/weight/dataset digests |
| T20 | API datasets/snapshots/jobs | OpenAPI contract tests and auth |
| T21 | Studio foundation/ui kit | routing, auth, errors, accessibility baseline |
| T22 | Virtualized Dataset Explorer | 10k images without full-load |
| T23 | Annotation classification UI | keyboard & revision history |
| T24 | Experiment Arena | paired runs, sample-by-sample deltas |
| T25 | End-to-end demo report | independent reproduction, screenshots/README |

## Capabilities com avaliação (T26–T37)
| Ticket | Entrega | Critério mínimo |
|---|---|---|
| T26 | Training PyTorch | checkpoint + deterministic config |
| T27 | Data quality advanced | meaningful duplicate/outlier signal |
| T28 | Visual search pgvector | recall@k measured + index versioning |
| T29 | Active learning random control | fair annotation budget and blinded test |
| T30 | Classifier calibration | reliability and reject curves |
| T31 | Cost ledger and Pareto chart | quality constraint and cost provenance |
| T32 | Model registry & approval | history, license gate, rollback pointer |
| T33 | Agent graph read-only | evidence correctness tests |
| T34 | MCP SDK v2 stdio | sdk + real host smoke, schemas/scopes |
| T35 | Agent proposal + approval | limits and stale-approval rejection |
| T36 | Chaos/security tests | crash recovery, injection, cross tenant |
| T37 | Studio traces/agent UX | all claims linked to artifacts |

## Regras de dependência
T01 before T04/T12. T03 before T06/T14/T20/T34. T07/T09 before T15/T16/T18. T13 before any claim de ML. T18 before T24/T25/T30/T31. T32 before release promotion; T33 before T35. Every experimental feature must have benchmark + rollback.

## PR guidance
Uma issue deve caber em 1–3 PRs focados. Evitar PRs que simultaneamente introduzam API, frontend, MCP e modelo novo. Preferir vertical integration controlled behind flags; registrar 2–5 fluxos públicos bem testados em vez de 50 comandos placeholders.
