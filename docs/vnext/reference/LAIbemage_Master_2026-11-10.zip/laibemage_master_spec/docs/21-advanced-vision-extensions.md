# 21 — Extensões de vídeo, segmentação, multimodal e Physical AI

As capacidades abaixo não devem bloquear o primeiro produto. Esta seção preserva os contratos necessários para futura implementação sem forçar os custos hoje.

## Detecção e segmentação
- JSON unions por task, no universal `label + confidence` para todos. Bbox `normalized_xywh` tem validação extra `x+width<=1`; orientar pixels antes de transformações. Segmentation masks armazenadas como artefatos, com affine transform e shape da imagem original.
- SAM/open-vocabulary segmenter como *pre-annotation adapter*, não verificador. Precisão de máscaras exige benchmark real e revisão.
- Pipeline: model predict → geometry QA → human review → annotations versionadas → snapshot → re-train/eval.
- COCO exporter implementa `images`, `annotations`, `categories`, correct segmentation masks/rles; YOLO object detection `class x_center y_center width height`, YOLO classification diretórios; testes de roundtrip para formatos.

## Vídeo e tracking
Modelo conceitual `VideoAsset`, `FrameSample`, `TimeRange`, `Track`, `Event`, `CaptureSession`, `CameraCalibration`. PTS/DTS, variable FPS, timebase e timestamp real guardados; não inferir sincronia de arquivos por nome. Sampling policy registrada por run para evitar avaliação enviesada. Algoritmos: detector + tracker + temporal event recognizer + VLM sumarizer com segmentos de evidência. Evals: temporal IoU, event F1, tracking IDF1/HOTA, latency per frame, false alarms/hour.

## Document intelligence
Pipeline: OCR region detection → text recognition → layout/table segmentation → field extraction → deterministic schema validation → evidence per page/bbox. Document-level holdout por template/vendor para medir generalização; CER/WER e field exact-match separados; PII redaction antes de cloud opt-in.

## Geospatial / remote sensing
Metadados EXIF+GPS+CRS tratados explicitamente, coordenadas com units e datum, tiles georreferenciados, sensitivity of location. Model eval agrupado por região/sensor/time; evitar leakage de mosaicos vizinhos. Se usar GIS, adicionar GDAL/Rasterio/geopandas como plugin isolado no Python stack, não dependência global em M0.

## Multisensor / Physical AI
Schema de sensor: `sensor_type, calibration_ref, timestamp_ns, pose_frame, coordinate_frame, units, synchronization_uncertainty`. Exigir transformações entre coordinate frames e sincronização antes da fusão. Armazenar depth/LiDAR binário fora DB, metadata e index por sample. Datasets robóticos podem ter políticas de ação; não executar controle físico por agente genérico.

## Dados sintéticos
Geradores: geometric transforms, photometric jitter, procedural defect compositions, diffusion/simulator. Cada sample sintético tem `generator, version, seed, prompt/parameters_digest, source_assets, validation_status`. Validação: detectar erros de label, medir distribuição, ganhar em holdout real; priorizar apenas quando a falta de dados reais é demonstrada. Não misturar sintéticos na avaliação final de performance real.

## Edge inference e hardware
Profiles CPU, Apple MPS/Core ML, CUDA/TensorRT, OpenVINO, WebGPU quando suportado. Export pipeline é artefato separado com model conversion digest e parity tests. Comparar preproc/postproc, scores, numerics, accuracy e latency, não apenas throughput. Budget de bateria/energia só com medição do dispositivo.

## Evolução de knowledge graph visual
Representar objetos, regiões, relações e eventos como `entity_id, predicate, target_id, image_region_or_time, source_model, confidence_kind, review_status`. Grafo derivado e reprocessável, não fonte única de verdade. PostgreSQL relational relations são suficientes em início; graph database somente se consultas de grafos realmente exigirem.
