# 22 — Auditoria estática do repositório atual e plano de migração

**Escopo:** inspeção estática da branch `main` de `https://github.com/erikunha/LAIbemage` no estado consultado em 2026-11-10, sem execução de testes ou benchmark de hardware. A descrição abaixo é observação de código/documentação, não validação funcional em produção.

## O que preservar
- `src/cli/index.ts`, `src/sdk.ts`: CLI com subcomandos e API TypeScript. Preservar compatibilidade observável.
- `src/analyzer/` e `src/analyzer/providers/`: adapters para OpenAI, Anthropic, Google, Azure, Bedrock, Ollama, Vertex e híbrido, batch, self-critique, link, temporal, embeddings.
- `src/processor/`: Sharp, exportação e overlay. Retê-lo como pipeline de transformação versionado, não confundir com classifier.
- `src/fs/`: FileRepository ports/adapters para local, memory, S3/GCS/Azure Blob. Reaproveitar interface de storage.
- `src/reporter/`: exportações HTML, SQLite, CSV e XLSX. Migrar relatórios de ML para datasets/eval específicos.
- `src/search/`: índice de embeddings com verificação de modelo/dimensões, útil como baseline antes do pgvector.
- `tests/`, `.github/workflows/`, `ROADMAP.md`, `AGENTS.md`, `CLAUDE.md`: preservar verificação existente e ADR history.

## Lacunas e riscos reais observados
1. `tests/fixtures/benchmark/labels.json` identifica **color swatches sintéticos** e informa que não são benchmark significativo de acurácia visual. Substituir apenas o benchmark científico, manter fixtures leves para smoke.
2. `src/analyzer/consensus.ts`: divergência entre provedores resolvida por **maior confidence autodeclarada**, não calibrada. Usar como heurística legada, comparar contra validation e encaminhar abstenção.
3. `src/analyzer/embeddings.ts`: embeddings são feitos sobre **descrições textuais**, não pixels de imagem. Persistir separadamente embeddings textuais e embeddings visuais, com model/preprocess hash.
4. `src/search/index.ts`: índice JSON + busca cosseno exaustiva (na memória). Boa referência; para dataset large, introduzir pgvector após baseline quantitativo.
5. `src/index.ts` `computeCategoriesHash`: hash calcula apenas nomes de categorias, **não suas descrições**; alterações de semântica não invalidam fingerprint. Além disso, modo `skip-analysis` avisa de hash divergente, mas prossegue com cache. Definir semântica e `strict`/compat mode antes de migrar.
6. `src/reviewer/index.ts`: revisão em terminal via TTY. Para workforce de annotators, Studio precisa de ferramentas de edição/revisão realmente visuais.
7. `src/types.ts`: `AnalysisResult` mistura resposta VLM com perspectiva de classificação; modelo Master precisa diferenciar `Prediction`, `Annotation`, `Evidence`, `Asset`, `DatasetSnapshot`.
8. `ROADMAP.md` antigo rejeita GUI/HTTP; isso é uma decisão de escopo anterior e precisa ser substituído por ADR/visão aprovada, **não** simplesmente reescrito retroativamente.
9. `package.json` usa versão `0.0.1` e pnpm package-manager `11.0.8`, enquanto workflow CI consultado usava pnpm `10` e testava Node `18/20/22`. Validar compatibilidade real, lockfile e publish workflow; não assumir que o projeto builda hoje.
10. Alguns status de roadmap divergem do código consultado: por exemplo, `embeddingModel` e `dimensions` já aparecem em `src/search/index.ts` apesar de um item ainda descrever isso como futuro. Tratar roadmap como histórico, não como inventário confiável sem checagem.

## LedgerLens: padrões transferíveis, sem copiar domínio
Referência: `https://github.com/erikunha/ledgerlens`.
- Tracing por run/span, evidências e verificação independente.
- Casos de avaliação reproduzíveis, baselines e documentação de limites.
- Agente com ferramentas e escopos restritos.
- Comparações com métricas e relatórios de falhas.
**Não reutilizar automaticamente:** lógica de pagamentos, SQL guards específicos, NLI textual como substituto de avaliação de visão, nem arquitetura de demo Streamlit como plataforma frontend.

## Plano de migração não destrutiva
1. Clone + tag do baseline + `pnpm install --frozen-lockfile`; registrar **resultado observado** de testes, typecheck, lint, coverage, benchmarks e build (não executar sem repo em ambiente local com deps).
2. Golden test do comando atual com fixtures e output determinístico; identificar exports SDK públicos.
3. Criar `contracts` e DTOs `Asset,Sample,Annotation,Prediction`; adaptar outputs legados sem quebrar CLI.
4. Criar `ApplicationService` para ingest/eval e refatorar `src/index.ts` gradualmente; migrar adaptadores sem reescrever providers de uma vez.
5. Separar pipelines `analyze → validate → persist prediction → request review → snapshot → train/eval` de `render/export JPEG`.
6. Adicionar Python worker com contrato e comparação ML; manter cloud providers opcionais.
7. Criar Studio primeiro para dataset explorer/classification review; deixar segmentação complexa para P1.
8. Descontinuar APIs legadas somente com changelog, janelas e testes de compatibilidade.

## Evidência insuficiente
Não foram executados benchmarks, instalação, cobertura, testes unitários ou E2E nesta análise. Qualquer meta de ganho, tempo ou custo é hipótese até teste. Valores apresentados em README do projeto são declarações da documentação, não medição repetida aqui.
