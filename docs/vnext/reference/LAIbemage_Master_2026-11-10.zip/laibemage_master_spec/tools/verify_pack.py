from pathlib import Path
import json, re, yaml
from jsonschema import Draft202012Validator
R=Path(__file__).resolve().parent.parent
errors=[]; results=[]
for f in R.rglob('*.json'):
    try:
        data=json.loads(f.read_text());
        if '$schema' in data: Draft202012Validator.check_schema(data)
        results.append('PASS JSON/schema: '+f.relative_to(R).as_posix())
    except Exception as e: errors.append(f'JSON ERROR {f}: {e}')
for f in R.rglob('*.yaml'):
    try:
        doc=yaml.safe_load(f.read_text())
        if not isinstance(doc,dict): raise ValueError('expected mapping')
        results.append('PASS YAML parse: '+f.relative_to(R).as_posix())
    except Exception as e: errors.append(f'YAML ERROR {f}: {e}')
for f in R.rglob('*.yml'):
    try: yaml.safe_load(f.read_text());results.append('PASS YAML parse: '+f.relative_to(R).as_posix())
    except Exception as e: errors.append(f'YAML ERROR {f}: {e}')
a=json.loads((R/'contracts/annotation.schema.json').read_text());validator=Draft202012Validator(a)
examples=[
 {'schema_version':1,'sample_id':'s1','ontology_version_id':'o1','source':'human','status':'approved','task_type':'classification','class_ids':['crack']},
 {'schema_version':1,'sample_id':'s2','ontology_version_id':'o1','source':'model','status':'suggested','task_type':'detection','objects':[{'class_id':'crack','box':{'x':0.1,'y':0.2,'width':0.4,'height':0.4,'coordinate_system':'normalized_xywh'}}]},
 {'schema_version':1,'sample_id':'s3','ontology_version_id':'o1','source':'human','status':'approved','task_type':'segmentation','masks':[{'class_id':'crack','artifact_ref':'art_1'}]}
]
for e in examples:
    errs=list(validator.iter_errors(e))
    if errs: errors.append(f'Annotation sample failed {e["task_type"]}: '+str(errs[0]))
    else: results.append('PASS annotation valid '+e['task_type'])
bad={**examples[0],'class_ids':[]}
if validator.is_valid(bad): errors.append('Annotation schema let through empty classes')
else: results.append('PASS annotation rejects empty class list')
openapi=yaml.safe_load((R/'contracts/openapi.yaml').read_text())
if openapi.get('openapi')!='3.1.0':errors.append('OpenAPI wrong version')
else:results.append('PASS OpenAPI 3.1 top-level parsed (NOT validator)')
for path,methods in openapi['paths'].items():
    for method,item in methods.items():
        if method in ('get','post','patch','put','delete'):
            if not item.get('responses'):errors.append('operation missing responses '+path+' '+method)
            if not item.get('operationId'):errors.append('operation missing id '+path+' '+method)
for f in R.rglob('*.md'):
    t=f.read_text()
    if t.count('```')%2:errors.append('Unclosed fence '+str(f))
    for target in re.findall(r'\]\(([^)#]+)(?:#[^)]+)?\)',t):
        if target.startswith(('http:','https:','mailto:')):continue
        ref=(f.parent/target)
        if not ref.exists():errors.append(f'Broken markdown ref {f.relative_to(R)} -> {target}')
results.append(f'PASS inspected {len(list(R.rglob("*.md")))} Markdown files for fences and relative links')
expected=[f'docs/{i:02}-' for i in range(23)]
for prefix in expected:
    if not any(f.relative_to(R).as_posix().startswith(prefix) for f in R.rglob('*.md')): errors.append('missing section '+prefix)
if not errors:results.append('PASS all 23 numbered docs present')
report='''# LAIbemage specification — Validation report

The following checks were **executed** against generated artifacts. This is documentation/static-contract validation only; no software implementation, SQL migration execution, Docker deployment or model benchmark was performed.

'''+ '\n'.join('- '+s for s in results) + '\n\n'
if errors: report+='## Errors\n'+ '\n'.join('- '+e for e in errors)+'\n'
else:report+='## Errors\nNone in executed checks.\n'
report+='''\n## Known limitations
- OpenAPI YAML parsed and its operation fields inspected; full semantic OpenAPI validator not available in this runtime.
- `reference_postgres.sql` is a proposed reference DDL, **not executed against PostgreSQL**. Composite tenant invariants, append-only triggers, RLS, state transition guards and migration scripts remain implementation work.
- No repository code, dependencies, Docker image, SDK or CLI was installed or executed as part of this documentation-generation task.
- Source references are official docs linked in `docs/15-research-references.md`; models and licensing must be rechecked when implementation begins.
'''
(R/'VALIDATION_REPORT.md').write_text(report)
print('VALIDATION ERROR COUNT',len(errors));print('\n'.join(errors));print('CHECKS',len(results))
if errors:raise SystemExit(1)
